// ============================================================
// PURCHASE ORDER ITEMS
// ============================================================
let poItemIndex = 0;
let editingPoId = null;
let previewPoData = null;

function addPoItemRow(data = null) {
  const tbody = document.getElementById('po-items-body');
  const idx = poItemIndex++;
  const row = document.createElement('tr');
  row.id = `po-item-row-${idx}`;
  row.innerHTML = `
    <td style="text-align:center;color:var(--text2);font-size:12px">${tbody.rows.length + 1}</td>
    <td><input type="text" placeholder="Nama item" value="${data?.name || ''}" oninput="calcPoTotals()" style="width:100%"></td>
    <td><input type="text" placeholder="Deskripsi item..." value="${data?.desc || ''}" style="width:100%"></td>
    <td><input type="text" placeholder="Pcs" value="${data?.unit || ''}" style="width:70px"></td>
    <td><input type="number" placeholder="0" value="${data?.qty || ''}" oninput="calcPoTotals()" style="width:70px"></td>
    <td><input type="number" placeholder="0" value="${data?.price || ''}" oninput="calcPoTotals()" style="width:110px"></td>
    <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--gold)" id="po-item-amount-${idx}">${data?.qty && data?.price ? fmtRpInv(data.qty * data.price) : 'Rp. 0'}</td>
    <td><button class="remove-row" onclick="removePoItemRow(this,'${idx}')">×</button></td>
  `;
  tbody.appendChild(row);
  calcPoTotals();
  renumberPoRows();
}

function removePoItemRow(btn, idx) {
  btn.closest('tr').remove();
  renumberPoRows();
  calcPoTotals();
}

function renumberPoRows() {
  document.querySelectorAll('#po-items-body tr').forEach((r, i) => {
    if (r.cells[0]) r.cells[0].textContent = i + 1;
  });
}

function getPoItemsData() {
  const rows = document.querySelectorAll('#po-items-body tr');
  return Array.from(rows).map(r => {
    const inputs = r.querySelectorAll('input');
    return {
      name:  inputs[0]?.value || '',
      desc:  inputs[1]?.value || '',
      unit:  inputs[2]?.value || '',
      qty:   parseFloat(inputs[3]?.value) || 0,
      price: parseFloat(inputs[4]?.value) || 0
    };
  });
}

// ============================================================
// CALCULATIONS
// ============================================================
function calcPoTotals() {
  let total = 0;
  document.querySelectorAll('#po-items-body tr').forEach(r => {
    // All inputs: [0]=name [1]=desc [2]=unit [3]=qty [4]=price
    const allInputs = r.querySelectorAll('input');
    const qty   = parseFloat(allInputs[3]?.value) || 0;
    const price = parseFloat(allInputs[4]?.value) || 0;
    const amt   = qty * price;
    total += amt;
    const idx  = (r.id || '').replace('po-item-row-', '');
    const amtEl = document.getElementById(`po-item-amount-${idx}`);
    if (amtEl) amtEl.textContent = fmtRpInv(amt);
  });

  document.getElementById('po-calc-total').textContent = fmtRpInv(total);

  const useDP = document.getElementById('po-use-dp')?.checked;
  const dpRows = document.getElementById('po-dp-total-rows');
  if (dpRows) dpRows.style.display = useDP ? '' : 'none';

  let dpAmt = 0, sisaAmt = total;
  if (useDP) {
    const method = document.getElementById('po-dp-method')?.value || 'pct';
    if (method === 'pct') {
      const pct = parseFloat(document.getElementById('po-dp-pct-val')?.value) || 0;
      dpAmt = total * pct / 100;
    } else {
      dpAmt = parseFloat(document.getElementById('po-dp-custom-val')?.value) || 0;
    }
    sisaAmt = total - dpAmt;
    const dpPctGroup = document.getElementById('po-dp-pct-group');
    const dpCustomGroup = document.getElementById('po-dp-custom-group');
    if (dpPctGroup) dpPctGroup.style.display = (method === 'pct') ? '' : 'none';
    if (dpCustomGroup) dpCustomGroup.style.display = (method === 'custom') ? '' : 'none';
    if (document.getElementById('po-dp-display'))   document.getElementById('po-dp-display').textContent   = fmtRpInv(dpAmt);
    if (document.getElementById('po-sisa-display')) document.getElementById('po-sisa-display').textContent = fmtRpInv(sisaAmt);
    if (document.getElementById('po-calc-dp'))       document.getElementById('po-calc-dp').textContent       = fmtRpInv(dpAmt);
    if (document.getElementById('po-calc-pelunasan')) document.getElementById('po-calc-pelunasan').textContent = fmtRpInv(sisaAmt);
  }

  return { total, dpAmt, sisaAmt };
}

function onPoUseDpChange() {
  const useDP = document.getElementById('po-use-dp').checked;
  document.getElementById('po-dp-detail').style.display = useDP ? '' : 'none';
  calcPoTotals();
}

// ============================================================
// NOMOR GENERATOR
// ============================================================
function generatePoNo(dateStr) {
  const d = dateStr ? new Date(dateStr) : new Date();
  const month = d.getMonth() + 1;
  const year  = d.getFullYear();
  const roman = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'][month - 1];
  const code  = (settings.companyCode || 'MBS').toUpperCase();
  const existing = purchaseOrders.filter(p => {
    if (editingPoId && p.id === editingPoId) return false;
    const pd = new Date(p.date);
    return pd.getMonth() + 1 === month && pd.getFullYear() === year;
  });
  const seq = String(existing.length + 1).padStart(3, '0');
  return `${seq}-PO/${code}/${roman}/${year}`;
}

function regeneratePoNo() {
  const dateVal = document.getElementById('po-date').value;
  document.getElementById('po-no').value = generatePoNo(dateVal);
}

// ============================================================
// RESET / SAVE / EDIT
// ============================================================
function resetPoForm() {
  editingPoId = null;
  poItemIndex = 0;
  document.getElementById('po-items-body').innerHTML = '';
  document.getElementById('po-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('po-quo-no').value = '';
  document.getElementById('po-vendor-name').value = '';
  document.getElementById('po-vendor-cp').value = '';
  document.getElementById('po-vendor-tel').value = '';
  document.getElementById('po-vendor-addr').value = '';
  document.getElementById('po-notes').value = '';
  document.getElementById('po-use-dp').checked = false;
  document.getElementById('po-dp-detail').style.display = 'none';
  document.getElementById('po-dp-method').value = 'pct';
  document.getElementById('po-dp-pct-val').value = 30;
  document.getElementById('po-dp-custom-val').value = 0;
  document.getElementById('po-dp-pct-group').style.display = '';
  document.getElementById('po-dp-custom-group').style.display = 'none';
  document.getElementById('po-sign-maker-select').value = 'quo';
  document.getElementById('po-sign-approver-select').value = 'approver';
  document.getElementById('po-form-title').textContent = 'Buat Purchase Order Baru';
  addPoItemRow();
  regeneratePoNo();
}

function savePurchaseOrder() {
  const date       = document.getElementById('po-date').value;
  const vendorName = document.getElementById('po-vendor-name').value;
  if (!date || !vendorName) { showToast('Harap isi tanggal dan nama vendor!', 'error'); return; }

  const items = getPoItemsData();
  const { total, dpAmt, sisaAmt } = calcPoTotals();
  const useDP = document.getElementById('po-use-dp').checked;

  const po = {
    id:         editingPoId || Date.now().toString(),
    no:         document.getElementById('po-no').value,
    date,
    quoNo:      document.getElementById('po-quo-no').value,
    vendorName,
    vendorCp:   document.getElementById('po-vendor-cp').value,
    vendorTel:  document.getElementById('po-vendor-tel').value,
    vendorAddr: document.getElementById('po-vendor-addr').value,
    notes:      document.getElementById('po-notes').value,
    signMakerKey:    document.getElementById('po-sign-maker-select').value,
    signApproverKey: document.getElementById('po-sign-approver-select').value,
    useDP,
    dpMethod:   document.getElementById('po-dp-method').value,
    dpPctVal:   parseFloat(document.getElementById('po-dp-pct-val').value) || 0,
    dpCustomVal: parseFloat(document.getElementById('po-dp-custom-val').value) || 0,
    items, total, dpAmt, sisaAmt
  };

  if (editingPoId) {
    const idx = purchaseOrders.findIndex(p => p.id === editingPoId);
    if (idx >= 0) purchaseOrders[idx] = po;
  } else {
    purchaseOrders.unshift(po);
  }

  saveData();
  showToast('Purchase Order berhasil disimpan!', 'success');
  showPage('dashboard');
}

function editPurchaseOrder(id) {
  const po = purchaseOrders.find(p => p.id === id);
  if (!po) return;
  editingPoId = id; poItemIndex = 0;
  document.getElementById('po-form-title').textContent = 'Edit Purchase Order';
  document.getElementById('po-no').value = po.no;
  document.getElementById('po-date').value = po.date;
  document.getElementById('po-quo-no').value = po.quoNo || '';
  document.getElementById('po-vendor-name').value = po.vendorName;
  document.getElementById('po-vendor-cp').value = po.vendorCp || '';
  document.getElementById('po-vendor-tel').value = po.vendorTel || '';
  document.getElementById('po-vendor-addr').value = po.vendorAddr || '';
  document.getElementById('po-notes').value = po.notes || '';
  document.getElementById('po-sign-maker-select').value = po.signMakerKey || 'quo';
  document.getElementById('po-sign-approver-select').value = po.signApproverKey || 'approver';
  document.getElementById('po-use-dp').checked = po.useDP || false;
  document.getElementById('po-dp-detail').style.display = po.useDP ? '' : 'none';
  document.getElementById('po-dp-method').value = po.dpMethod || 'pct';
  document.getElementById('po-dp-pct-val').value = po.dpPctVal || 30;
  document.getElementById('po-dp-custom-val').value = po.dpCustomVal || 0;
  document.getElementById('po-dp-pct-group').style.display = (po.dpMethod === 'custom') ? 'none' : '';
  document.getElementById('po-dp-custom-group').style.display = (po.dpMethod === 'custom') ? '' : 'none';
  document.getElementById('po-items-body').innerHTML = '';
  po.items.forEach(item => addPoItemRow(item));
  calcPoTotals();
  showPage('create-po');
}

function deletePurchaseOrder(id) {
  if (!confirm('Yakin ingin menghapus purchase order ini?')) return;
  purchaseOrders = purchaseOrders.filter(p => p.id !== id);
  saveData(); renderDashboard(); showToast('Purchase Order dihapus.', 'success');
}

function previewPurchaseOrder() {
  const items = getPoItemsData();
  const { total, dpAmt, sisaAmt } = calcPoTotals();
  const useDP = document.getElementById('po-use-dp').checked;
  const po = {
    no:         document.getElementById('po-no').value,
    date:       document.getElementById('po-date').value,
    quoNo:      document.getElementById('po-quo-no').value,
    vendorName: document.getElementById('po-vendor-name').value,
    vendorCp:   document.getElementById('po-vendor-cp').value,
    vendorAddr: document.getElementById('po-vendor-addr').value,
    notes:      document.getElementById('po-notes').value,
    signMakerKey:    document.getElementById('po-sign-maker-select').value,
    signApproverKey: document.getElementById('po-sign-approver-select').value,
    useDP, dpAmt, sisaAmt,
    items, total
  };
  previewPoData = po;
  document.getElementById('po-modal-title').textContent = 'Preview Purchase Order ' + po.no;
  document.getElementById('po-render').innerHTML = renderPoHTML(po);
  document.getElementById('po-modal').classList.add('open');
}

function viewPurchaseOrder(id) {
  const po = purchaseOrders.find(p => p.id === id);
  if (!po) return;
  previewPoData = po;
  document.getElementById('po-modal-title').textContent = 'Purchase Order ' + po.no;
  document.getElementById('po-render').innerHTML = renderPoHTML(po);
  document.getElementById('po-modal').classList.add('open');
}

function closePoModal() {
  document.getElementById('po-modal').classList.remove('open');
}

// ============================================================
// HELPER: resolve signer from key
// ============================================================
function resolveSign(key) {
  const s = settings;
  if (key === 'maker')    return { name: s.signMaker || '', role: s.signMakerRole || '', ttd: s.ttd_maker || '' };
  if (key === 'quo')      return { name: s.quoSignName || '', role: s.quoSignRole || '', ttd: s.ttd_quo || '' };
  if (key === 'approver') return { name: s.signApprover || '', role: s.signApproverRole || '', ttd: s.ttd_approver || '' };
  return { name: '', role: '', ttd: '' };
}

// ============================================================
// RENDER PO HTML
// ============================================================
function renderPoHTML(po) {
  const s = settings;
  const logoHTML = s.logo
    ? `<img src="${s.logo}" style="width:48px;height:48px;object-fit:contain">`
    : `<div style="width:48px;height:48px;background:#FFC000;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:13px;flex-shrink:0">${(s.companyCode||'MBS').slice(0,3)}</div>`;

  const npwpParts = [];
  if (s.npwp)    npwpParts.push(`NPWP. ${s.npwp}`);
  if (s.pkp)     npwpParts.push(`PKP. ${s.pkp}`);
  if (s.email)   npwpParts.push(s.email);
  if (s.phone)   npwpParts.push(`| ${s.phone}`);

  const dateFormatted = (() => {
    if (!po.date) return '-';
    const d = new Date(po.date + 'T00:00:00');
    return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
  })();

  const itemsHTML = po.items.map((item, i) => `
    <tr>
      <td style="text-align:center;padding:7px 9px;border:1px solid #ddd;font-size:10.5px">${i+1}</td>
      <td style="padding:7px 9px;border:1px solid #ddd;font-size:10.5px;font-weight:600">${item.name}</td>
      <td style="padding:7px 9px;border:1px solid #ddd;font-size:10.5px;color:#555">${(item.desc||'').replace(/\n/g,'<br>')}</td>
      <td style="text-align:center;padding:7px 9px;border:1px solid #ddd;font-size:10.5px">${item.unit}</td>
      <td style="text-align:right;padding:7px 9px;border:1px solid #ddd;font-size:10.5px">${item.qty}</td>
      <td style="text-align:right;padding:7px 9px;border:1px solid #ddd;font-size:10.5px">${fmtRpInv(item.price)}</td>
      <td style="text-align:right;padding:7px 9px;border:1px solid #ddd;font-size:10.5px;font-weight:600">${fmtRpInv(item.qty * item.price)}</td>
    </tr>`).join('');

  const terbilangText = terbilang(Math.round(po.useDP && po.dpAmt ? po.dpAmt : po.total)) + ' Rupiah';

  const maker    = resolveSign(po.signMakerKey    || 'quo');
  const approver = resolveSign(po.signApproverKey || 'approver');

  return `
<div style="padding:28px 32px;background:#fff;font-family:'Plus Jakarta Sans',sans-serif">

  <!-- HEADER -->
  <div style="display:flex;gap:0;border:1px solid #ddd">
    <!-- Left: company info -->
    <div style="flex:1;padding:12px 16px;display:flex;gap:12px;align-items:flex-start">
      ${logoHTML}
      <div>
        <div style="font-size:14px;font-weight:800;color:#111">${s.companyName}</div>
        <div style="font-size:9px;color:#555;margin-top:3px;line-height:1.6">${(s.address||'').replace(/\n/g,'<br>')}</div>
        ${npwpParts.length ? `<div style="font-size:8.5px;color:#777;margin-top:3px">${npwpParts.join(' | ')}</div>` : ''}
      </div>
    </div>
    <!-- Right: PO badge + meta -->
    <div style="background:#FFC000;min-width:220px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px 20px">
      <div style="font-size:18px;font-weight:800;color:#111;letter-spacing:.06em;margin-bottom:10px">PURCHASE ORDER</div>
      <table style="font-size:10px;color:#111;border-collapse:collapse;width:100%">
        <tr><td style="padding:2px 4px;opacity:.85">NO.PO</td><td style="padding:2px 4px">:</td><td style="padding:2px 4px;font-weight:700">${po.no}</td></tr>
        <tr><td style="padding:2px 4px;opacity:.85">Tanggal</td><td style="padding:2px 4px">:</td><td style="padding:2px 4px;font-weight:700">${dateFormatted}</td></tr>
        <tr><td style="padding:2px 4px;opacity:.85">Quo.No</td><td style="padding:2px 4px">:</td><td style="padding:2px 4px;font-weight:700">${po.quoNo || ''}</td></tr>
      </table>
    </div>
  </div>

  <!-- VENDOR + DELIVERY -->
  <div style="display:grid;grid-template-columns:1fr 1fr;border:1px solid #ddd;border-top:none">
    <div style="padding:12px 16px;border-right:1px solid #ddd">
      <div style="font-size:9.5px;color:#888;margin-bottom:6px">To :</div>
      <div style="font-size:11px;font-weight:700;color:#111">${po.vendorCp || po.vendorName}</div>
      <div style="font-size:10px;color:#555;margin-top:3px">${po.vendorName}</div>
      ${po.vendorAddr ? `<div style="font-size:9.5px;color:#777;margin-top:3px">${po.vendorAddr.replace(/\n/g,'<br>')}</div>` : ''}
    </div>
    <div style="padding:12px 16px">
      <div style="font-size:9.5px;color:#888;margin-bottom:6px;font-weight:700">Delivery To:</div>
      <div style="font-size:11px;font-weight:700;color:#111">${s.companyName}</div>
      <div style="font-size:9.5px;color:#555;margin-top:3px;line-height:1.6">${(s.address||'').replace(/\n/g,'<br>')}</div>
      ${(maker.name) ? `<div style="font-size:9.5px;color:#555;margin-top:3px">${maker.name}${maker.role ? ' ('+maker.role+')' : ''}</div>` : ''}
    </div>
  </div>

  <!-- ITEMS TABLE -->
  <table style="width:100%;border-collapse:collapse;margin-top:14px">
    <thead>
      <tr style="background:#FFC000">
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:center;color:#111;border:1px solid #e6a800;width:32px">NO</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:left;color:#111;border:1px solid #e6a800">ITEM</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:left;color:#111;border:1px solid #e6a800">DESC</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:center;color:#111;border:1px solid #e6a800;width:55px">UNIT</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:right;color:#111;border:1px solid #e6a800;width:50px">QTY</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:right;color:#111;border:1px solid #e6a800;width:110px">UNIT PRICE</th>
        <th style="padding:8px 9px;font-size:9.5px;font-weight:700;text-align:right;color:#111;border:1px solid #e6a800;width:120px">AMOUNT</th>
      </tr>
    </thead>
    <tbody>
      ${itemsHTML}
    </tbody>
  </table>

  <!-- TOTALS -->
  <div style="display:flex;justify-content:flex-end;margin-top:0">
    <table style="border-collapse:collapse;min-width:260px">
      <tr style="background:#FFC000">
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:center">TOTAL AMOUNT</td>
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:right">${fmtRpInv(po.total)}</td>
      </tr>
      ${po.useDP ? `
      <tr style="background:#FFC000">
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:center">DP</td>
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:right">${fmtRpInv(po.dpAmt)}</td>
      </tr>
      <tr style="background:#FFC000">
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:center">PELUNASAN</td>
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:right">${fmtRpInv(po.sisaAmt)}</td>
      </tr>` : `
      <tr style="background:#FFC000">
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:center">PELUNASAN</td>
        <td style="padding:7px 12px;font-size:10.5px;font-weight:700;color:#111;border:1px solid #e6a800;text-align:right">${fmtRpInv(po.total)}</td>
      </tr>`}
    </table>
  </div>

  <!-- TERBILANG -->
  <div style="background:#fffbf0;border:1px solid #f0e0b0;border-left:3px solid #FFC000;border-radius:5px;padding:7px 12px;font-size:10px;color:#7a5a00;margin-top:12px">
    Terbilang : <em style="font-weight:600">${terbilangText}</em>
  </div>

  <!-- NOTES -->
  ${po.notes ? `<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:5px;padding:8px 12px;font-size:10px;color:#444;margin-top:10px"><strong style="display:block;font-size:9px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;color:#888">Notes :</strong>${po.notes.replace(/\n/g,'<br>')}</div>` : `<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:5px;padding:8px 12px;font-size:10px;color:#aaa;margin-top:10px;font-style:italic"><strong style="display:block;font-size:9px;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px">Notes :</strong>&nbsp;</div>`}

  <!-- SIGNATURES -->
  <div style="display:flex;justify-content:space-between;margin-top:28px">
    <div style="text-align:center;font-size:10px">
      <div style="color:#555;margin-bottom:4px">Dibuat Oleh,</div>
      ${maker.ttd ? `<img src="${maker.ttd}" style="height:70px;max-width:140px;object-fit:contain;display:block;margin:0 auto">` : '<div style="height:70px"></div>'}
      <div style="font-weight:700;border-top:1px solid #aaa;padding-top:3px;display:inline-block;min-width:110px">${maker.name}</div>
      <div style="color:#777;font-size:9.5px">${maker.role}</div>
    </div>
    <div style="text-align:center;font-size:10px">
      <div style="color:#555;margin-bottom:4px">Disetujui Oleh,</div>
      ${approver.ttd ? `<img src="${approver.ttd}" style="height:70px;max-width:140px;object-fit:contain;display:block;margin:0 auto">` : '<div style="height:70px"></div>'}
      <div style="font-weight:700;border-top:1px solid #aaa;padding-top:3px;display:inline-block;min-width:110px">${approver.name}</div>
      <div style="color:#777;font-size:9.5px">${approver.role}</div>
    </div>
  </div>

  <!-- FOOTER -->
  <div style="background:#FFC000;text-align:center;padding:6px 0;margin-top:18px;font-size:9.5px;font-style:italic;color:#111">
    Terima Kasih atas kepercayaan dan kerjasama dengan Perusahaan Kami
  </div>

</div>`;
}
