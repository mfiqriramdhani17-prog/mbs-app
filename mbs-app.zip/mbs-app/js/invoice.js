// ============================================================
// INVOICE ITEMS
// ============================================================
function addItemRow(data = null) {
  const tbody = document.getElementById('items-body');
  const idx = itemIndex++;
  const usePhoto = document.getElementById('use-photo').checked;
  const imgData = data?.image || '';
  if (imgData) itemRowImages[idx] = imgData;

  const row = document.createElement('tr');
  row.id = `item-row-${idx}`;
  row.innerHTML = `
    <td style="text-align:center;color:var(--text2);font-size:12px">${tbody.rows.length + 1}</td>
    <td class="col-photo" style="display:${usePhoto ? 'table-cell' : 'none'}">
      <div class="item-img-cell">
        <img id="img-preview-${idx}" class="item-img-thumb" src="${imgData}" style="display:${imgData ? 'block':'none'}">
        <input type="file" id="img-input-${idx}" accept="image/*" style="display:none" onchange="handleItemImage(${idx}, this)">
        <button class="item-img-btn" onclick="document.getElementById('img-input-${idx}').click()">📷 Pilih</button>
        <button class="item-img-btn" onclick="clearItemImage(${idx})" style="${imgData ? '' : 'display:none'}" id="img-clear-${idx}">✕</button>
      </div>
    </td>
    <td><input type="text" placeholder="Nama item" value="${data?.name || ''}" oninput="calcTotals()" style="width:100%"></td>
    <td><input type="text" placeholder="Pcs" value="${data?.unit || ''}" style="width:100%"></td>
    <td><input type="number" placeholder="0" value="${data?.qty || ''}" oninput="calcTotals()" style="width:100%"></td>
    <td><input type="number" placeholder="0" value="${data?.price || ''}" oninput="calcTotals()" style="width:100%"></td>
    <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--gold)" id="item-amount-${idx}">${data?.qty && data?.price ? fmtRp(data.qty * data.price) : 'Rp 0'}</td>
    <td><button class="remove-row" onclick="removeItemRow(this,'${idx}')">×</button></td>
  `;
  tbody.appendChild(row);
  calcTotals();
  renumberRows('items-body');
}

function handleItemImage(idx, input) {
  const file = input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    itemRowImages[idx] = e.target.result;
    const img = document.getElementById(`img-preview-${idx}`);
    const clr = document.getElementById(`img-clear-${idx}`);
    if (img) { img.src = e.target.result; img.style.display = 'block'; }
    if (clr) clr.style.display = '';
  };
  reader.readAsDataURL(file);
}
function clearItemImage(idx) {
  delete itemRowImages[idx];
  const img = document.getElementById(`img-preview-${idx}`);
  const clr = document.getElementById(`img-clear-${idx}`);
  if (img) { img.src = ''; img.style.display = 'none'; }
  if (clr) clr.style.display = 'none';
}
function removeItemRow(btn, idx) { btn.closest('tr').remove(); delete itemRowImages[idx]; renumberRows('items-body'); calcTotals(); }
function renumberRows(tbodyId) { document.querySelectorAll('#' + tbodyId + ' tr').forEach((r, i) => { if (r.cells[0]) r.cells[0].textContent = i + 1; }); }
function togglePhotoCol() { const show = document.getElementById('use-photo').checked; document.querySelectorAll('.col-photo').forEach(el => { el.style.display = show ? 'table-cell' : 'none'; }); }
function getItemsData() {
  const rows = document.querySelectorAll('#items-body tr');
  return Array.from(rows).map(r => {
    const inputs = r.querySelectorAll('input[type=text], input[type=number]');
    const idx = r.id.replace('item-row-', '');
    return { name: inputs[0].value, unit: inputs[1].value, qty: parseFloat(inputs[2].value) || 0, price: parseFloat(inputs[3].value) || 0, image: itemRowImages[idx] || '' };
  });
}

// ============================================================
// CALCULATIONS
// ============================================================
function fmtRp(n) { return 'Rp ' + Math.round(n).toLocaleString('id-ID'); }
function fmtRpInv(n) { return 'Rp. ' + Math.round(n).toLocaleString('id-ID'); }

function calcTotals() {
  const rows = document.querySelectorAll('#items-body tr');
  let sub = 0;
  rows.forEach(r => {
    const inputs = r.querySelectorAll('input[type=number]');
    const numInputs = Array.from(inputs);
    if (numInputs.length >= 2) {
      const qty = parseFloat(numInputs[numInputs.length - 2].value) || 0;
      const price = parseFloat(numInputs[numInputs.length - 1].value) || 0;
      const amt = qty * price;
      sub += amt;
      const idx = r.id.replace('item-row-', '');
      const amtEl = document.getElementById(`item-amount-${idx}`);
      if (amtEl) amtEl.textContent = fmtRp(amt);
    }
  });

  const usePpn = document.getElementById('use-ppn')?.checked !== false;
  const ppnPct = parseFloat(document.getElementById('ppn-pct').value) || 0;
  const pphPct = parseFloat(document.getElementById('pph-pct').value) || 0;
  let dpp = 0, ppn = 0, pph = 0, grand = sub;
  if (usePpn) { dpp = sub*(11/12); ppn = dpp*(ppnPct/100); pph = sub*(pphPct/100); grand = sub+ppn-pph; }

  document.getElementById('calc-subtotal').textContent = fmtRp(sub);
  document.getElementById('calc-dpp').textContent = fmtRp(dpp);
  document.getElementById('calc-ppn').textContent = fmtRp(ppn);
  document.getElementById('calc-pph').textContent = fmtRp(pph);
  document.getElementById('calc-grand').textContent = fmtRp(grand);
  const taxRows = document.getElementById('tax-rows');
  if (taxRows) taxRows.style.display = usePpn ? '' : 'none';

  const termin = document.getElementById('inv-termin')?.value || 'PELUNASAN';
  const isDpTermin = termin !== 'PELUNASAN';
  const isPelunasan = termin === 'PELUNASAN';
  const dpPanel = document.getElementById('dp-panel');
  const dpTotalRows = document.getElementById('dp-total-rows');
  const pelunasanPanel = document.getElementById('pelunasan-panel');
  const pelunasanTotalRows = document.getElementById('pelunasan-total-rows');
  if (dpPanel) dpPanel.style.display = isDpTermin ? '' : 'none';
  if (dpTotalRows) dpTotalRows.style.display = isDpTermin ? '' : 'none';
  if (pelunasanPanel) pelunasanPanel.style.display = isPelunasan ? '' : 'none';

  let dpAmt = 0, sisaAmt = 0;
  if (isDpTermin) {
    const method = document.getElementById('dp-method')?.value || 'pct';
    dpAmt = method === 'pct' ? grand * (parseFloat(document.getElementById('dp-pct-val').value)||0)/100 : parseFloat(document.getElementById('dp-custom-val').value)||0;
    sisaAmt = grand - dpAmt;
    const dpLabelRow = document.getElementById('dp-label-row');
    if (dpLabelRow) dpLabelRow.textContent = termin;
    if (document.getElementById('dp-amount-display')) document.getElementById('dp-amount-display').textContent = fmtRp(dpAmt);
    if (document.getElementById('dp-sisa-display')) document.getElementById('dp-sisa-display').textContent = fmtRp(sisaAmt);
    if (document.getElementById('calc-dp-val')) document.getElementById('calc-dp-val').textContent = fmtRp(dpAmt);
    if (document.getElementById('calc-sisa-val')) document.getElementById('calc-sisa-val').textContent = fmtRp(sisaAmt);
  }

  let sudahAmt = 0, pelunasanSisa = grand;
  if (isPelunasan) {
    const useSudah = document.getElementById('use-sudah-dibayar')?.checked;
    if (pelunasanTotalRows) pelunasanTotalRows.style.display = useSudah ? '' : 'none';
    if (useSudah) {
      const sudahMethod = document.getElementById('sudah-method')?.value || 'pct';
      sudahAmt = sudahMethod === 'pct' ? grand*(parseFloat(document.getElementById('sudah-pct-val')?.value)||0)/100 : parseFloat(document.getElementById('sudah-custom-val')?.value)||0;
      pelunasanSisa = grand - sudahAmt;
      if (document.getElementById('sudah-amount-display')) document.getElementById('sudah-amount-display').textContent = fmtRp(sudahAmt);
      if (document.getElementById('sudah-sisa-display')) document.getElementById('sudah-sisa-display').textContent = fmtRp(pelunasanSisa);
      if (document.getElementById('calc-sudah-val')) document.getElementById('calc-sudah-val').textContent = fmtRp(sudahAmt);
      if (document.getElementById('calc-pelunasan-sisa-val')) document.getElementById('calc-pelunasan-sisa-val').textContent = fmtRp(pelunasanSisa);
    }
  } else { if (pelunasanTotalRows) pelunasanTotalRows.style.display = 'none'; }

  return { sub, dpp, ppn, pph, grand, ppnPct, pphPct, usePpn, dpAmt, sisaAmt, sudahAmt, pelunasanSisa };
}

function onTerminChange() { regenerateInvoiceNo(); calcTotals(); }
function onDpMethodChange() {
  const method = document.getElementById('dp-method').value;
  document.getElementById('dp-pct-group').style.display = method === 'pct' ? '' : 'none';
  document.getElementById('dp-custom-group').style.display = method === 'custom' ? '' : 'none';
  calcTotals();
}
function onSudahDibayarChange() { document.getElementById('sudah-dibayar-detail').style.display = document.getElementById('use-sudah-dibayar').checked ? '' : 'none'; calcTotals(); }
function onSudahMethodChange() {
  const method = document.getElementById('sudah-method').value;
  document.getElementById('sudah-pct-group').style.display = method === 'pct' ? '' : 'none';
  document.getElementById('sudah-custom-group').style.display = method === 'custom' ? '' : 'none';
  calcTotals();
}

// ============================================================
// TERBILANG
// ============================================================
function terbilang(n) {
  n = Math.floor(Math.abs(n));
  if (n === 0) return 'Nol';
  const satuan = ['','Satu','Dua','Tiga','Empat','Lima','Enam','Tujuh','Delapan','Sembilan'];
  const belasan = ['Sepuluh','Sebelas','Dua Belas','Tiga Belas','Empat Belas','Lima Belas','Enam Belas','Tujuh Belas','Delapan Belas','Sembilan Belas'];
  const puluhan = ['','','Dua Puluh','Tiga Puluh','Empat Puluh','Lima Puluh','Enam Puluh','Tujuh Puluh','Delapan Puluh','Sembilan Puluh'];
  function helper(num) {
    if (num===0) return '';
    if (num<10) return satuan[num];
    if (num<20) return belasan[num-10];
    if (num<100) return puluhan[Math.floor(num/10)]+(num%10?' '+satuan[num%10]:'');
    if (num<200) return 'Seratus'+(num%100?' '+helper(num%100):'');
    if (num<1000) return satuan[Math.floor(num/100)]+' Ratus'+(num%100?' '+helper(num%100):'');
    if (num<2000) return 'Seribu'+(num%1000?' '+helper(num%1000):'');
    if (num<1000000) return helper(Math.floor(num/1000))+' Ribu'+(num%1000?' '+helper(num%1000):'');
    if (num<1000000000) return helper(Math.floor(num/1000000))+' Juta'+(num%1000000?' '+helper(num%1000000):'');
    if (num<1000000000000) return helper(Math.floor(num/1000000000))+' Miliar'+(num%1000000000?' '+helper(num%1000000000):'');
    return helper(Math.floor(num/1000000000000))+' Triliun'+(num%1000000000000?' '+helper(num%1000000000000):'');
  }
  return helper(n);
}

// ============================================================
// BANK SELECTOR HELPER
// ============================================================
function refreshBankSelect(selectedIdx) {
  const sel = document.getElementById('inv-bank-select');
  if (!sel) return;
  sel.innerHTML = '';
  const banks = settings.banks || [];
  if (banks.length === 0) {
    sel.innerHTML = '<option value="">— Belum ada rekening —</option>';
    return;
  }
  banks.forEach((b, i) => {
    const opt = document.createElement('option');
    opt.value = i;
    opt.textContent = `${b.name} — ${b.account}`;
    if (i === (selectedIdx || 0)) opt.selected = true;
    sel.appendChild(opt);
  });
}

// ============================================================
// RESET / SAVE / EDIT
// ============================================================
function resetForm() {
  editingId = null; itemIndex = 0; itemRowImages = {};
  document.getElementById('items-body').innerHTML = '';
  document.getElementById('inv-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('inv-po').value = '';
  document.getElementById('inv-client-code').value = '';
  document.getElementById('inv-client-name').value = '';
  document.getElementById('inv-client-cp').value = '';
  document.getElementById('inv-client-addr').value = '';
  document.getElementById('inv-client-tel').value = '';
  document.getElementById('inv-notes').value = '';
  document.getElementById('ppn-pct').value = 12;
  document.getElementById('pph-pct').value = 2;
  document.getElementById('use-photo').checked = false;
  document.getElementById('use-ppn').checked = true;
  document.getElementById('inv-termin').value = 'DP';
  document.getElementById('dp-method').value = 'pct';
  document.getElementById('dp-pct-val').value = 30;
  document.getElementById('dp-custom-val').value = 0;
  document.getElementById('dp-pct-group').style.display = '';
  document.getElementById('dp-custom-group').style.display = 'none';
  document.getElementById('use-sudah-dibayar').checked = false;
  document.getElementById('sudah-dibayar-detail').style.display = 'none';
  document.getElementById('sudah-method').value = 'pct';
  document.getElementById('sudah-pct-val').value = 30;
  document.getElementById('sudah-custom-val').value = 0;
  document.getElementById('sudah-pct-group').style.display = '';
  document.getElementById('sudah-custom-group').style.display = 'none';
  const badge = document.getElementById('inv-autofill-badge');
  if (badge) badge.style.display = 'none';
  refreshBankSelect(0);
  togglePhotoCol();
  document.getElementById('form-page-title').textContent = 'Buat Invoice Baru';
  addItemRow();
  regenerateInvoiceNo();
}

function saveInvoice() {
  const date = document.getElementById('inv-date').value;
  const clientName = document.getElementById('inv-client-name').value;
  if (!date || !clientName) { showToast('Harap isi tanggal dan nama klien!', 'error'); return; }
  const { sub, dpp, ppn, pph, grand, ppnPct, pphPct, usePpn, dpAmt, sisaAmt, sudahAmt, pelunasanSisa } = calcTotals();
  const items = getItemsData();
  const termin = document.getElementById('inv-termin').value;
  const inv = {
    id: editingId || Date.now().toString(),
    no: document.getElementById('inv-no').value,
    date, po: document.getElementById('inv-po').value, termin,
    usePhoto: document.getElementById('use-photo').checked,
    usePpn, dpMethod: document.getElementById('dp-method').value,
    dpPctVal: parseFloat(document.getElementById('dp-pct-val').value) || 0,
    useSudahDibayar: document.getElementById('use-sudah-dibayar')?.checked || false,
    sudahMethod: document.getElementById('sudah-method')?.value || 'pct',
    sudahPctVal: parseFloat(document.getElementById('sudah-pct-val')?.value) || 0,
    clientCode: document.getElementById('inv-client-code').value,
    clientName, clientCp: document.getElementById('inv-client-cp').value,
    clientAddr: document.getElementById('inv-client-addr').value,
    notes: document.getElementById('inv-notes').value,
    selectedBankIdx: parseInt(document.getElementById('inv-bank-select')?.value ?? 0) || 0,
    items, sub, dpp, ppn, pph, grand, ppnPct, pphPct, dpAmt, sisaAmt, sudahAmt, pelunasanSisa,
    itemImages: { ...itemRowImages }
  };
  if (editingId) { const idx = invoices.findIndex(i => i.id === editingId); if (idx >= 0) invoices[idx] = inv; }
  else invoices.unshift(inv);
  saveData();
  showToast('Invoice berhasil disimpan!', 'success');
  showPage('dashboard');
}

function editInvoice(id) {
  const inv = invoices.find(i => i.id === id);
  if (!inv) return;
  editingId = id; itemIndex = 0; itemRowImages = {};
  (inv.items || []).forEach((item, i) => { if (item.image) itemRowImages[i] = item.image; });
  document.getElementById('form-page-title').textContent = 'Edit Invoice';
  document.getElementById('inv-no').value = inv.no;
  document.getElementById('inv-date').value = inv.date;
  document.getElementById('inv-po').value = inv.po || '';
  document.getElementById('inv-client-code').value = inv.clientCode || '';
  document.getElementById('inv-client-name').value = inv.clientName;
  document.getElementById('inv-client-cp').value = inv.clientCp || '';
  document.getElementById('inv-client-addr').value = inv.clientAddr || '';
  document.getElementById('inv-client-tel').value = '';
  document.getElementById('inv-notes').value = inv.notes || '';
  document.getElementById('ppn-pct').value = inv.ppnPct || 12;
  document.getElementById('pph-pct').value = inv.pphPct || 2;
  document.getElementById('use-photo').checked = inv.usePhoto || false;
  document.getElementById('use-ppn').checked = inv.usePpn !== false;
  document.getElementById('inv-termin').value = inv.termin || 'DP';
  document.getElementById('dp-method').value = inv.dpMethod || 'pct';
  document.getElementById('dp-pct-val').value = inv.dpPctVal || 30;
  document.getElementById('dp-custom-val').value = inv.dpAmt || 0;
  document.getElementById('dp-pct-group').style.display = (inv.dpMethod === 'custom') ? 'none' : '';
  document.getElementById('dp-custom-group').style.display = (inv.dpMethod === 'custom') ? '' : 'none';
  const useSudah = inv.useSudahDibayar || false;
  document.getElementById('use-sudah-dibayar').checked = useSudah;
  document.getElementById('sudah-dibayar-detail').style.display = useSudah ? '' : 'none';
  document.getElementById('sudah-method').value = inv.sudahMethod || 'pct';
  document.getElementById('sudah-pct-val').value = inv.sudahPctVal || 30;
  document.getElementById('sudah-custom-val').value = inv.sudahAmt || 0;
  document.getElementById('sudah-pct-group').style.display = (inv.sudahMethod === 'custom') ? 'none' : '';
  document.getElementById('sudah-custom-group').style.display = (inv.sudahMethod === 'custom') ? '' : 'none';
  togglePhotoCol();
  refreshBankSelect(inv.selectedBankIdx || 0);
  document.getElementById('items-body').innerHTML = '';
  inv.items.forEach(item => addItemRow(item));
  calcTotals();
  showPage('create');
}

function deleteInvoice(id) {
  if (!confirm('Yakin ingin menghapus invoice ini?')) return;
  invoices = invoices.filter(i => i.id !== id);
  saveData(); renderDashboard(); showToast('Invoice dihapus.', 'success');
}

function previewInvoice() {
  const { sub, dpp, ppn, pph, grand, ppnPct, pphPct, usePpn, dpAmt, sisaAmt, sudahAmt, pelunasanSisa } = calcTotals();
  const termin = document.getElementById('inv-termin').value;
  const inv = {
    no: document.getElementById('inv-no').value,
    date: document.getElementById('inv-date').value,
    po: document.getElementById('inv-po').value,
    termin, clientName: document.getElementById('inv-client-name').value,
    clientCp: document.getElementById('inv-client-cp').value,
    clientAddr: document.getElementById('inv-client-addr').value,
    notes: document.getElementById('inv-notes').value,
    items: getItemsData(), sub, dpp, ppn, pph, grand, ppnPct, pphPct, usePpn, dpAmt, sisaAmt,
    useSudahDibayar: document.getElementById('use-sudah-dibayar')?.checked || false,
    sudahMethod: document.getElementById('sudah-method')?.value || 'pct',
    sudahPctVal: parseFloat(document.getElementById('sudah-pct-val')?.value) || 0,
    sudahAmt, pelunasanSisa,
    selectedBankIdx: parseInt(document.getElementById('inv-bank-select')?.value ?? 0) || 0,
    usePhoto: document.getElementById('use-photo').checked,
    itemImages: { ...itemRowImages }
  };
  previewInvData = inv;
  document.getElementById('modal-title').textContent = 'Preview Invoice ' + inv.no;
  document.getElementById('invoice-render').innerHTML = renderInvoiceHTML(inv);
  document.getElementById('invoice-modal').classList.add('open');
}

function viewInvoice(id) {
  const inv = invoices.find(i => i.id === id);
  if (!inv) return;
  if (!inv.itemImages || Object.keys(inv.itemImages).length === 0) {
    const rebuilt = {};
    (inv.items || []).forEach((item, idx) => { if (item.image) rebuilt[idx] = item.image; });
    inv.itemImages = rebuilt;
  }
  previewInvData = inv;
  document.getElementById('modal-title').textContent = 'Invoice ' + inv.no;
  document.getElementById('invoice-render').innerHTML = renderInvoiceHTML(inv);
  document.getElementById('invoice-modal').classList.add('open');
}

function renderInvoiceHTML(inv) {
  const s = settings;
  const logoHTML = s.logo ? `<img class="inv-logo-img" src="${s.logo}" alt="logo">` : `<div class="inv-logo-placeholder">${(s.companyCode||'MBS').slice(0,3)}</div>`;
  const npwpParts = [];
  if (s.npwp) npwpParts.push(`NPWP. ${s.npwp}`);
  if (s.pkp) npwpParts.push(`PKP. ${s.pkp}`);
  if (s.email) npwpParts.push(s.email);
  if (s.phone) npwpParts.push(s.phone);
  if (s.website) npwpParts.push(s.website);

  const usePhoto = inv.usePhoto;
  const imgCol = usePhoto ? `<th style="width:90px">Foto</th>` : '';
  const itemsHTML = inv.items.map((item, i) => {
    const imgSrc = item.image || (inv.itemImages && inv.itemImages[i]) || '';
    const imgTd = usePhoto ? `<td>${imgSrc ? `<img class="inv-item-img" src="${imgSrc}">` : ''}</td>` : '';
    return `<tr>
      <td style="text-align:center">${i+1}</td>
      <td>${item.name}</td>
      <td>-</td>
      ${imgTd}
      <td style="text-align:center">${item.unit}</td>
      <td style="text-align:right">${item.qty}</td>
      <td style="text-align:right">${fmtRpInv(item.price)}</td>
      <td style="text-align:right;font-weight:600">${fmtRpInv(item.qty * item.price)}</td>
    </tr>`;
  }).join('');

  // Bank: gunakan rekening yang dipilih user, fallback ke semua jika tidak ada
  let bankObj = null;
  if (inv.selectedBankIdx !== undefined && s.banks && s.banks[inv.selectedBankIdx]) {
    bankObj = s.banks[inv.selectedBankIdx];
  } else if (s.banks && s.banks.length > 0) {
    bankObj = s.banks[0];
  }
  const banksHTML = bankObj
    ? `<div class="inv-bank-entry"><strong>${bankObj.name}</strong></div><div class="inv-bank-entry">${bankObj.account}</div><div class="inv-bank-entry">${bankObj.holder}</div>`
    : '<div class="inv-bank-entry" style="color:#aaa;font-style:italic">Belum ada rekening bank</div>';
  const terbilangAmt = (inv.termin !== 'PELUNASAN' && inv.dpAmt) ? inv.dpAmt : (inv.termin === 'PELUNASAN' && inv.useSudahDibayar && inv.sudahAmt) ? inv.pelunasanSisa : inv.grand;
  const terbilangText = terbilang(Math.round(terbilangAmt)) + ' Rupiah';
  const fullDateStr = formatDate(inv.date);

  return `
<div class="inv-header">
  <div>
    <div class="inv-logo-area">${logoHTML}<div><div class="inv-company-name">${s.companyName}</div><div class="inv-company-addr">${(s.address||'').replace(/\n/g,'<br>')}</div></div></div>
    ${npwpParts.length ? `<div class="inv-npwp-bar">${npwpParts.join(' | ')}</div>` : ''}
  </div>
  <div class="inv-badge-area">
    <div class="inv-badge">INVOICE</div>
    <div class="inv-meta"><table>
      <tr><td>NO.Invoice</td><td>:</td><td>${inv.no}</td></tr>
      <tr><td>Hari/Tanggal</td><td>:</td><td>${fullDateStr}</td></tr>
      <tr><td>No.PO</td><td>:</td><td>${inv.po || '-'}</td></tr>
    </table></div>
  </div>
</div>
<hr class="inv-divider">
<div class="inv-recipient-box">
  <div class="label">Dikirim Kepada :</div>
  <div class="company">${inv.clientName}</div>
  <div style="margin-top:4px;font-size:10.5px;color:#444">${(inv.clientAddr||'').replace(/\n/g,'<br>')}</div>
  ${inv.clientCp ? `<div style="margin-top:4px;font-size:10.5px;color:#666">u.p ${inv.clientCp}</div>` : ''}
</div>
<table class="inv-items-table">
  <thead><tr>
    <th style="width:32px">NO</th><th>ITEM</th><th style="width:36px">DESC</th>
    ${imgCol}
    <th style="width:55px">UNIT</th><th style="width:50px;text-align:right">QTY</th>
    <th style="width:110px;text-align:right">UNIT PRICE</th><th style="width:120px;text-align:right">AMOUNT</th>
  </tr></thead>
  <tbody>
    ${itemsHTML}
    <tr><td colspan="${usePhoto?7:6}" style="text-align:right;font-weight:700;font-size:12px;background:#f9fafb">TOTAL</td>
      <td style="text-align:right;font-weight:700;font-size:12px;background:#f9fafb">${fmtRpInv(inv.sub)}</td></tr>
  </tbody>
</table>
<div class="inv-totals">
  <div class="inv-totals-inner">
    ${inv.usePpn !== false ? `
    <div class="inv-total-row"><span>DPP NILAI LAIN</span><span>${fmtRpInv(inv.dpp)}</span></div>
    <div class="inv-total-row"><span>PPN (${inv.ppnPct}%)</span><span>${fmtRpInv(inv.ppn)}</span></div>
    <div class="inv-total-row"><span>PPH (${inv.pphPct}%)</span><span>${fmtRpInv(inv.pph)}</span></div>
    ` : ''}
    <div class="inv-total-grand"><span>GRAND TOTAL</span><span>${fmtRpInv(inv.grand)}</span></div>
    ${inv.termin !== 'PELUNASAN' && inv.dpAmt ? `<div class="inv-total-row" style="background:#fffbf0;color:#7a5a00;font-weight:600"><span>${inv.termin||'DP'}</span><span>${fmtRpInv(inv.dpAmt)}</span></div>` : ''}
    ${inv.termin === 'PELUNASAN' && inv.useSudahDibayar && inv.sudahAmt ? `
    <div class="inv-total-row" style="background:#f0faf5;color:#2d7a5a;font-weight:600"><span>Sudah Dibayar (DP)</span><span style="text-decoration:line-through;opacity:.7">${fmtRpInv(inv.sudahAmt)}</span></div>
    <div style="display:flex;justify-content:space-between;padding:8px 10px;font-size:13px;font-weight:800;background:#1a6a3a;color:#fff"><span>PELUNASAN</span><span>${fmtRpInv(inv.pelunasanSisa)}</span></div>
    ` : ''}
  </div>
</div>
<div class="inv-terbilang">Terbilang : <span>${terbilangText}</span></div>
<div class="inv-bank-notes">
  <div class="inv-bank-box"><div class="bank-title">Bank Account</div>${banksHTML}</div>
  ${inv.notes ? `<div class="inv-notes-box"><strong>Notes :</strong><em>${inv.notes}</em></div>` : ''}
</div>
<div class="inv-sign-area">
  <div class="inv-sign-col">
    <div style="font-size:9.5px;color:#888;margin-bottom:4px">Dibuat Oleh,</div>
    ${s.ttd_maker ? `<img src="${s.ttd_maker}" style="height:75px;max-width:150px;object-fit:contain;display:block;margin:0 auto">` : '<div class="inv-sign-space"></div>'}
    <div class="inv-sign-name">${s.signMaker||''}</div>
    <div class="inv-sign-role">${s.signMakerRole||''}</div>
  </div>
  <div class="inv-sign-col"></div>
  <div class="inv-sign-col">
    <div style="font-size:9.5px;color:#888;margin-bottom:4px">${s.companyName}</div>
    ${s.ttd_approver ? `<img src="${s.ttd_approver}" style="height:75px;max-width:150px;object-fit:contain;display:block;margin:0 auto">` : '<div class="inv-sign-space"></div>'}
    <div class="inv-sign-name">${s.signApprover||''}</div>
    <div class="inv-sign-role">${s.signApproverRole||''}</div>
  </div>
</div>
<div class="inv-footer-bar">Terima kasih atas kepercayaan dan kerja sama Anda</div>`;
}

function formatDate(d) {
  if (!d) return '-';
  const dt = new Date(d + 'T00:00:00');
  const hariList = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
  const hari = hariList[dt.getDay()];
  const dateStr = dt.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  return hari + ', ' + dateStr;
}
