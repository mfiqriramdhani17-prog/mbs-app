// ============================================================
// SUPABASE CONFIG — ganti dengan URL & anon key project kamu
// ============================================================
const SUPABASE_URL = 'https://qkrhodnousjqbzzoktwq.supabase.co'; // ← ganti
const SUPABASE_KEY = 'sb_publishable_zy3sGSN82ZBgz-6T4mxvfw_V52nn08S';         // ← ganti (anon public)

// Supabase REST helper — tanpa SDK, pakai fetch langsung
const sb = {
  _h() {
    return {
      'Content-Type': 'application/json',
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
    };
  },
  async select(table) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=*&order=created_at.desc`, {
      headers: this._h()
    });
    if (!res.ok) throw new Error(`Supabase select [${table}] HTTP ${res.status}`);
    return res.json();
  },
  async upsert(table, data) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
      method: 'POST',
      headers: { ...this._h(), 'Prefer': 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error(`Supabase upsert [${table}] HTTP ${res.status}`);
  },
  async remove(table, id) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: this._h()
    });
    if (!res.ok) throw new Error(`Supabase delete [${table}] HTTP ${res.status}`);
  }
};

// ============================================================
// DATA LAYER
// ============================================================
let settings = {
  companyName: 'CV Mahkota Berkah Semesta',
  companyCode: 'MBS',
  address: 'Jl. Supratman No.94, Kel. Cihaurgeulis, Kec. Cibeunying Kaler, Kota Bandung, Jawa Barat 40222',
  phone: '0812-2308-9940',
  email: 'official@mahkotaberkahsemesta.com',
  website: 'mahkotaberkahsemesta.com',
  npwp: '63.768.446.5-423.000',
  pkp: 'S-235/PKP/KPP.090203/2023',
  logo: '',
  banks: [{ name: 'BANK CENTRAL ASIA (BCA)', account: '514 2777 118', holder: 'CV Mahkota Berkah Semesta' }],
  signMaker: 'Fiqri Ramdhani',
  signMakerRole: 'Admin',
  signApprover: 'Arman Girana',
  signApproverRole: 'Direktur',
  quoSignName: 'Vety Wijayanti',
  quoSignRole: 'Manager Marketing',
  sjSignName: 'Fiqri',
  ttd_maker: '', ttd_approver: '', ttd_quo: '', ttd_sj: ''
};

let invoices = [];
let quotations = [];
let suratJalans = [];
let purchaseOrders = [];
let clients = [];
let vendors = [];

let editingId = null;
let editingQuoId = null;
let editingSjId = null;
let itemIndex = 0;
let quoItemIndex = 0;
let sjItemIndex = 0;
let itemRowImages = {};
let quoItemRowImages = {};

// Global preview data — shared across all modules
let previewInvData = null;
let previewSjData  = null;
let previewQuoData = null;


// ============================================================
// INDEXED DB
// ============================================================

function openDB() {

  return new Promise((resolve, reject) => {

    const request = indexedDB.open('mbs-db', 1);

    request.onupgradeneeded = () => {

      if (!request.result.objectStoreNames.contains('handles')) {
        request.result.createObjectStore('handles');
      }

    };

    request.onsuccess = () => resolve(request.result);

    request.onerror = () => reject(request.error);

  });

}

async function saveDirHandle(dirHandle) {

  const db = await openDB();

  return new Promise((resolve, reject) => {

    const tx = db.transaction('handles', 'readwrite');

    tx.objectStore('handles').put(dirHandle, 'saveDir');

    tx.oncomplete = () => resolve();

    tx.onerror = () => reject(tx.error);

  });

}

async function loadDirHandle() {

  const db = await openDB();

  return new Promise((resolve, reject) => {

    const tx = db.transaction('handles', 'readonly');

    const req = tx.objectStore('handles').get('saveDir');

    req.onsuccess = () => resolve(req.result);

    req.onerror = () => reject(req.error);

  });

}

// ============================================================
// FILE-BASED PERSISTENCE (File System Access API)
// Menyimpan data ke folder "save/" sebagai file JSON terpisah
// ============================================================
let _saveDir = null; // FileSystemDirectoryHandle folder "save/"

/** Coba dapatkan handle folder save/ — minta izin sekali, lalu ingat */
async function getSaveDir() {

  // Sudah ada di memory
  if (_saveDir) {

    const perm = await _saveDir.queryPermission({
      mode: 'readwrite'
    });

    if (perm === 'granted') return _saveDir;

  }

  // Coba load dari IndexedDB
  _saveDir = await loadDirHandle();

  if (_saveDir) {

    const perm = await _saveDir.queryPermission({
      mode: 'readwrite'
    });

    if (perm === 'granted') {
      return _saveDir;
    }

  }

  // Minta pilih folder baru
  try {

    _saveDir = await window.showDirectoryPicker({
      id: 'mbs-save',
      mode: 'readwrite',
      startIn: 'documents'
    });

    // SIMPAN HANDLE
    await saveDirHandle(_saveDir);

    return _saveDir;

  } catch (e) {

    return null;

  }

}

/** Tulis satu file JSON ke folder save/ */
async function writeJson(dir, filename, data) {
  const fh = await dir.getFileHandle(filename, { create: true });
  const writable = await fh.createWritable();
  await writable.write(JSON.stringify(data, null, 2));
  await writable.close();
}

/** Baca satu file JSON dari folder save/ */
async function readJson(dir, filename) {
  try {
    const fh = await dir.getFileHandle(filename);
    const file = await fh.getFile();
    const text = await file.text();
    return JSON.parse(text);
  } catch (e) {
    return null; // File belum ada = data kosong
  }
}

// ============================================================
// SUPABASE — SAVE & LOAD
// ============================================================

/**
 * saveData() — simpan ke Supabase (utama) + localStorage (fallback/cache).
 * Dipanggil persis seperti sebelumnya dari semua modul.
 */
async function saveData() {
  // 1. Selalu cache ke localStorage supaya app tetap responsif offline
  try {
    localStorage.setItem('mbs_settings',       JSON.stringify(settings));
    localStorage.setItem('mbs_invoices',       JSON.stringify(invoices));
    localStorage.setItem('mbs_quotations',     JSON.stringify(quotations));
    localStorage.setItem('mbs_suratjalan',     JSON.stringify(suratJalans));
    localStorage.setItem('mbs_purchaseorders', JSON.stringify(purchaseOrders));
    localStorage.setItem('mbs_clients',        JSON.stringify(clients));
    localStorage.setItem('mbs_vendors',        JSON.stringify(vendors));
  } catch(e) { console.error('LS cache error:', e); }

  // 2. Simpan ke Supabase
  try {
    await Promise.all([
      sb.upsert('mbs_settings',       [{ id: 'main', data: settings }]),
      sb.upsert('mbs_invoices',       invoices.map(r => ({ id: r.id, data: r }))),
      sb.upsert('mbs_quotations',     quotations.map(r => ({ id: r.id, data: r }))),
      sb.upsert('mbs_suratjalan',     suratJalans.map(r => ({ id: r.id, data: r }))),
      sb.upsert('mbs_purchaseorders', purchaseOrders.map(r => ({ id: r.id, data: r }))),
      sb.upsert('mbs_clients',        clients.map(r => ({ id: r.id, data: r }))),
      sb.upsert('mbs_vendors',        vendors.map(r => ({ id: r.id, data: r }))),
    ]);
    updateDbStatus('supabase', 'Supabase');
    showToast('Data berhasil disimpan ke Supabase!', 'success');
  } catch(e) {
    console.error('Supabase save error:', e);
    updateDbStatus('ls', 'localStorage (Supabase gagal)');
    showToast('Supabase gagal — data tersimpan lokal saja.', 'error');
  }
}

/**
 * loadFromSupabase() — muat semua data dari Supabase.
 * Dipanggil saat DOMContentLoaded.
 */
async function loadFromSupabase() {
  try {
    updateDbStatus('loading', 'Menghubungkan ke Supabase...');
    const [sRows, iRows, qRows, sjRows, poRows, clRows, vdRows] = await Promise.all([
      sb.select('mbs_settings'),
      sb.select('mbs_invoices'),
      sb.select('mbs_quotations'),
      sb.select('mbs_suratjalan'),
      sb.select('mbs_purchaseorders'),
      sb.select('mbs_clients'),
      sb.select('mbs_vendors'),
    ]);
    const s = sRows.find(r => r.id === 'main');
    if (s)      settings       = Object.assign(settings, s.data);
    if (iRows)  invoices       = iRows.map(r => r.data);
    if (qRows)  quotations     = qRows.map(r => r.data);
    if (sjRows) suratJalans    = sjRows.map(r => r.data);
    if (poRows) purchaseOrders = poRows.map(r => r.data);
    if (clRows) clients        = clRows.map(r => r.data);
    if (vdRows) vendors        = vdRows.map(r => r.data);

    // Update cache lokal
    localStorage.setItem('mbs_settings',       JSON.stringify(settings));
    localStorage.setItem('mbs_invoices',       JSON.stringify(invoices));
    localStorage.setItem('mbs_quotations',     JSON.stringify(quotations));
    localStorage.setItem('mbs_suratjalan',     JSON.stringify(suratJalans));
    localStorage.setItem('mbs_purchaseorders', JSON.stringify(purchaseOrders));
    localStorage.setItem('mbs_clients',        JSON.stringify(clients));
    localStorage.setItem('mbs_vendors',        JSON.stringify(vendors));

    updateDbStatus('supabase', 'Supabase ✓');
    if (typeof refreshClientDatalist === 'function') refreshClientDatalist();
    if (typeof refreshVendorDatalist === 'function') refreshVendorDatalist();
    return true;
  } catch(e) {
    console.error('Supabase load error:', e);
    updateDbStatus('ls', 'localStorage (offline)');
    showToast('Supabase tidak bisa dijangkau — memuat dari cache lokal.', 'error');
    return false;
  }
}

/** Muat semua data dari folder save/ */
async function loadFromDir(dir) {
  try {
    const s  = await readJson(dir, 'settings.json');
    const i  = await readJson(dir, 'invoices.json');
    const q  = await readJson(dir, 'quotations.json');
    const sj = await readJson(dir, 'suratjalan.json');
    const po = await readJson(dir, 'purchaseorders.json');
    const cl = await readJson(dir, 'clients.json');
    const vd = await readJson(dir, 'vendors.json');

    if (s)  settings       = Object.assign(settings, s);
    if (i)  invoices       = i;
    if (q)  quotations     = q;
    if (sj) suratJalans    = sj;
    if (po) purchaseOrders = po;
    if (cl) clients        = cl;
    if (vd) vendors        = vd;
    // Refresh datalists after folder load
    if (typeof refreshClientDatalist === 'function') refreshClientDatalist();
    if (typeof refreshVendorDatalist === 'function') refreshVendorDatalist();
    return true;
  } catch(e) {
    console.error('Load error:', e);
    return false;
  }
}

/** Muat dari localStorage — dipakai sebagai cache awal sebelum Supabase selesai load */
function loadFromLocalStorage() {
  try {
    const s  = localStorage.getItem('mbs_settings');
    const i  = localStorage.getItem('mbs_invoices');
    const q  = localStorage.getItem('mbs_quotations');
    const sj = localStorage.getItem('mbs_suratjalan');
    const po = localStorage.getItem('mbs_purchaseorders');
    const cl = localStorage.getItem('mbs_clients');
    const vd = localStorage.getItem('mbs_vendors');
    if (s)  settings       = Object.assign(settings, JSON.parse(s));
    if (i)  invoices       = JSON.parse(i);
    if (q)  quotations     = JSON.parse(q);
    if (sj) suratJalans    = JSON.parse(sj);
    if (po) purchaseOrders = JSON.parse(po);
    if (cl) clients        = JSON.parse(cl);
    if (vd) vendors        = JSON.parse(vd);
  } catch(e) { console.error('LS load error:', e); }
}

/** Dipanggil user dari tombol "Pilih Folder Data" */
async function pickAndLoadSaveDir() {
  updateDbStatus('loading', 'Memilih folder...');
  const dir = await getSaveDir();
  if (!dir) { updateDbStatus('ls', 'Folder tidak dipilih'); return; }

  const ok = await loadFromDir(dir);
  if (ok) {
    updateDbStatus('folder', dir.name);
    updateSidebarLogo();
    renderDashboard();
    if (document.getElementById('page-settings').classList.contains('active')) loadSettingsForm();
    if (document.getElementById('page-clients').classList.contains('active')) renderClientsPage();
    showToast('Data dimuat dari folder: ' + dir.name, 'success');
  } else {
    updateDbStatus('folder', dir.name + ' (kosong)');
    showToast('Folder dipilih. Data baru akan disimpan di sini.', 'success');
  }
}

window.addEventListener('DOMContentLoaded', async () => {
  // Langsung muat dari Supabase dulu
  const ok = await loadFromSupabase();
  if (!ok) loadFromLocalStorage(); // fallback kalau Supabase gagal
  if (ok) {
    updateSidebarLogo();
    renderDashboard();
    if (typeof loadSettingsForm === 'function' &&
        document.getElementById('page-settings')?.classList.contains('active')) {
      loadSettingsForm();
    }
  }

  // File System Access API tetap disimpan tapi tidak aktif dipakai
  try {
    _saveDir = await loadDirHandle();
  } catch(e) { /* abaikan */ }
});

function updateDbStatus(mode, label) {
  const el = document.getElementById('db-status');
  if (!el) return;
  const icons = { supabase: '☁️', folder: '📁', ls: '💾', loading: '⏳', error: '⚠️' };
  el.innerHTML = `<span style="opacity:.6">${icons[mode]||'💾'}</span> ${label}`;
  const titles = {
    supabase: 'Terhubung ke Supabase',
    folder:   'Data disimpan ke folder: ' + label,
    ls:       'Data disimpan ke localStorage (sementara / offline)'
  };
  el.title = titles[mode] || label;
}

// loadFromLocalStorage() dipanggil di DOMContentLoaded (setelah DOM siap)

// ============================================================
// CLIENT LOOKUP
// ============================================================
function getClientByCode(code) {
  return clients.find(c => c.code && c.code.toLowerCase() === code.toLowerCase());
}

function autofillClient(prefix) {
  const codeEl = document.getElementById(prefix + '-client-code');
  if (!codeEl) return;
  const code = codeEl.value.trim();
  if (!code) return;
  const client = getClientByCode(code);
  if (!client) { showToast('Kode klien tidak ditemukan', 'error'); return; }

  const nameEl = document.getElementById(prefix + '-client-name');
  const addrEl = document.getElementById(prefix + '-client-addr');
  const cpEl   = document.getElementById(prefix + '-client-cp');
  const telEl  = document.getElementById(prefix + '-client-tel');

  if (nameEl) nameEl.value = client.name || '';
  if (addrEl) addrEl.value = client.address || '';
  if (cpEl)   cpEl.value   = client.contact || '';
  if (telEl)  telEl.value  = client.phone || '';

  const badge = document.getElementById(prefix + '-autofill-badge');
  if (badge) { badge.style.display = 'inline-flex'; badge.querySelector('span').textContent = client.name; }

  showToast('Data klien berhasil diisi otomatis!', 'success');
}

// ============================================================
// NAV
// ============================================================
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pg = document.getElementById('page-' + name);
  if (pg) pg.classList.add('active');
  const navMap = {
    'dashboard':  'nav-dashboard',
    'create':     'nav-create',
    'create-quo': 'nav-create-quo',
    'create-po':  'nav-create-po',
    'create-sj':  'nav-create-sj',
    'clients':    'nav-clients',
    'vendors':    'nav-vendors',
    'settings':   'nav-settings'
  };
  const navId = navMap[name];
  if (navId) { const el = document.getElementById(navId); if (el) el.classList.add('active'); }
  if (name === 'dashboard') renderDashboard();
  if (name === 'settings') loadSettingsForm();
  if (name === 'clients') renderClientsPage();
  if (name === 'vendors') renderVendorsPage();
}

function switchDashTab(tab, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.getElementById('dash-tab-' + tab).classList.add('active');
}

// ============================================================
// NUMBER GENERATORS
// ============================================================
const ROMAN = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

function generateInvoiceNo(dateStr, termin) {
  const d = dateStr ? new Date(dateStr) : new Date();
  const month = d.getMonth() + 1;
  const year = d.getFullYear();
  const roman = ROMAN[month - 1];
  const code = (settings.companyCode || 'MBS').toUpperCase();
  const existing = invoices.filter(inv => {
    if (editingId && inv.id === editingId) return false;
    const id = new Date(inv.date);
    return id.getMonth() + 1 === month && id.getFullYear() === year;
  });
  const seq = String(existing.length + 1).padStart(2, '0');
  const terminPart = termin === 'PELUNASAN' ? '' : '/DP';
  return `${month}${seq}/INV${terminPart}/${code}/${roman}/${year}`;
}

function regenerateInvoiceNo() {
  const dateVal = document.getElementById('inv-date').value;
  const termin = document.getElementById('inv-termin')?.value || 'DP';
  document.getElementById('inv-no').value = generateInvoiceNo(dateVal, termin);
}

function generateQuoNo(dateStr) {
  const d = dateStr ? new Date(dateStr) : new Date();
  const month = d.getMonth() + 1;
  const year = d.getFullYear();
  const roman = ROMAN[month - 1];
  const code = (settings.companyCode || 'MBS').toUpperCase();
  const existing = quotations.filter(q => {
    if (editingQuoId && q.id === editingQuoId) return false;
    const qd = new Date(q.date);
    return qd.getMonth() + 1 === month && qd.getFullYear() === year;
  });
  const seq = String(existing.length + 1).padStart(2, '0');
  return `${month}${seq}/QUO/${code}/${roman}/${year}`;
}

function regenerateQuoNo() {
  const dateVal = document.getElementById('quo-date').value;
  document.getElementById('quo-no').value = generateQuoNo(dateVal);
}

function generateSjNo(dateStr) {
  const d = dateStr ? new Date(dateStr) : new Date();
  const month = d.getMonth() + 1;
  const year = d.getFullYear();
  const roman = ROMAN[month - 1];
  const code = (settings.companyCode || 'MBS').toUpperCase();
  const existing = suratJalans.filter(sj => {
    if (editingSjId && sj.id === editingSjId) return false;
    const sd = new Date(sj.date);
    return sd.getMonth() + 1 === month && sd.getFullYear() === year;
  });
  const seq = String(existing.length + 1).padStart(3, '0');
  return `${seq}-SJ/${code}/${roman}/${year}`;
}

function regenerateSjNo() {
  const dateVal = document.getElementById('sj-date').value;
  document.getElementById('sj-no').value = generateSjNo(dateVal);
}

// ============================================================
// FORMAT HELPERS
// ============================================================
const ONES = ['','satu','dua','tiga','empat','lima','enam','tujuh','delapan','sembilan','sepuluh','sebelas'];
function terbilang(n) {
  n = Math.round(n);
  if (n < 0) return 'minus ' + terbilang(-n);
  if (n === 0) return 'nol';
  if (n < 12) return ONES[n];
  if (n < 20) return terbilang(n - 10) + ' belas';
  if (n < 100) return terbilang(Math.floor(n/10)) + ' puluh' + (n%10 ? ' ' + terbilang(n%10) : '');
  if (n < 200) return 'seratus' + (n > 100 ? ' ' + terbilang(n - 100) : '');
  if (n < 1000) return terbilang(Math.floor(n/100)) + ' ratus' + (n%100 ? ' ' + terbilang(n%100) : '');
  if (n < 2000) return 'seribu' + (n > 1000 ? ' ' + terbilang(n - 1000) : '');
  if (n < 1000000) return terbilang(Math.floor(n/1000)) + ' ribu' + (n%1000 ? ' ' + terbilang(n%1000) : '');
  if (n < 1000000000) return terbilang(Math.floor(n/1000000)) + ' juta' + (n%1000000 ? ' ' + terbilang(n%1000000) : '');
  return terbilang(Math.floor(n/1000000000)) + ' miliar' + (n%1000000000 ? ' ' + terbilang(n%1000000000) : '');
}

function formatRp(n) {
  return 'Rp ' + Number(n || 0).toLocaleString('id-ID');
}

function formatDateID(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  const days = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
  const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  return `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateShort(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('id-ID', { day:'2-digit', month:'short', year:'numeric' });
}

// ============================================================
// TOAST
// ============================================================
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'show ' + type;
  setTimeout(() => { t.className = ''; }, 2800);
}

// ============================================================
// MODAL HELPERS
// ============================================================
function closeModal() { document.getElementById('invoice-modal').classList.remove('open'); }
function closeQuoModal() { document.getElementById('quo-modal').classList.remove('open'); }
function closeSjModal() { document.getElementById('sj-modal').classList.remove('open'); }

// ============================================================
// SIDEBAR LOGO
// ============================================================
function updateSidebarLogo() {
  const el = document.getElementById('sidebar-logo-display');
  if (settings.logo) { el.innerHTML = `<img src="${settings.logo}" style="width:32px;height:32px;object-fit:contain;border-radius:6px">`; el.style.background = 'transparent'; }
  else { el.innerHTML = (settings.companyCode || 'MBS').slice(0,3); el.style.background = ''; }
}
