// ============================================================
// SURAT JALAN ITEMS
// ============================================================
function addSjItemRow(data = null) {
  const tbody = document.getElementById('sj-items-body');
  const idx = sjItemIndex++;
  const row = document.createElement('tr');
  row.id = `sj-item-row-${idx}`;
  row.innerHTML = `
    <td style="text-align:center;color:var(--text2);font-size:12px">${tbody.rows.length + 1}</td>
    <td><input type="text" placeholder="Nama barang" value="${data?.name || ''}" oninput="calcSjTotal()" style="width:100%"></td>
    <td><input type="text" placeholder="Pcs" value="${data?.unit || ''}" style="width:70px"></td>
    <td><input type="text" placeholder="M, L, XL..." value="${data?.size || ''}" style="width:70px"></td>
    <td><input type="number" placeholder="0" value="${data?.qty || ''}" oninput="calcSjTotal()" style="width:80px"></td>
    <td><input type="text" placeholder="..." value="${data?.keterangan || ''}" style="width:100%"></td>
    <td><button class="remove-row" onclick="removeSjItemRow(this,'${idx}')">×</button></td>
  `;
  tbody.appendChild(row);
  calcSjTotal();
  renumberSjRows();
}

function removeSjItemRow(btn, idx) {
  btn.closest('tr').remove();
  renumberSjRows();
  calcSjTotal();
}

function renumberSjRows() {
  document.querySelectorAll('#sj-items-body tr').forEach((r, i) => { if (r.cells[0]) r.cells[0].textContent = i + 1; });
}

function calcSjTotal() {
  let total = 0;
  document.querySelectorAll('#sj-items-body tr').forEach(r => {
    const qtyInput = r.querySelector('input[type=number]');
    if (qtyInput) total += parseFloat(qtyInput.value) || 0;
  });
  const el = document.getElementById('sj-total-display');
  if (el) el.textContent = total;
}

function getSjItemsData() {
  const rows = document.querySelectorAll('#sj-items-body tr');
  return Array.from(rows).map(r => {
    const inputs = r.querySelectorAll('input');
    return {
      name: inputs[0]?.value || '',
      unit: inputs[1]?.value || '',
      size: inputs[2]?.value || '',
      qty: parseFloat(inputs[3]?.value) || 0,
      keterangan: inputs[4]?.value || ''
    };
  });
}

// ============================================================
// RESET / SAVE / EDIT SURAT JALAN
// ============================================================
function resetSjForm() {
  editingSjId = null;
  sjItemIndex = 0;
  document.getElementById('sj-items-body').innerHTML = '';
  document.getElementById('sj-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('sj-po').value = '';
  document.getElementById('sj-polisi').value = '';
  document.getElementById('sj-driver').value = '';
  document.getElementById('sj-client-code').value = '';
  document.getElementById('sj-client-name').value = '';
  document.getElementById('sj-client-addr').value = '';
  document.getElementById('sj-client-cp').value = '';
  document.getElementById('sj-client-tel').value = '';
  document.getElementById('sj-sign-select').value = 'maker';
  const badge = document.getElementById('sj-autofill-badge');
  if (badge) badge.style.display = 'none';
  document.getElementById('sj-form-title').textContent = 'Buat Surat Jalan Baru';
  addSjItemRow();
  regenerateSjNo();
}

function saveSuratJalan() {
  const date = document.getElementById('sj-date').value;
  const clientName = document.getElementById('sj-client-name').value;
  if (!date || !clientName) { showToast('Harap isi tanggal dan nama penerima!', 'error'); return; }

  const items = getSjItemsData();
  const total = items.reduce((s, it) => s + (it.qty || 0), 0);
  const sj = {
    id: editingSjId || Date.now().toString(),
    no: document.getElementById('sj-no').value,
    date, po: document.getElementById('sj-po').value,
    polisi: document.getElementById('sj-polisi').value,
    driver: document.getElementById('sj-driver').value,
    clientCode: document.getElementById('sj-client-code').value,
    clientName, clientAddr: document.getElementById('sj-client-addr').value,
    clientCp: document.getElementById('sj-client-cp').value,
    clientTel: document.getElementById('sj-client-tel').value,
    signSelect: document.getElementById('sj-sign-select').value,
    items, total
  };
  if (editingSjId) { const idx = suratJalans.findIndex(s => s.id === editingSjId); if (idx >= 0) suratJalans[idx] = sj; }
  else suratJalans.unshift(sj);
  saveData();
  showToast('Surat Jalan berhasil disimpan!', 'success');
  showPage('dashboard');
}

function editSuratJalan(id) {
  const sj = suratJalans.find(s => s.id === id);
  if (!sj) return;
  editingSjId = id; sjItemIndex = 0;
  document.getElementById('sj-form-title').textContent = 'Edit Surat Jalan';
  document.getElementById('sj-no').value = sj.no;
  document.getElementById('sj-date').value = sj.date;
  document.getElementById('sj-po').value = sj.po || '';
  document.getElementById('sj-polisi').value = sj.polisi || '';
  document.getElementById('sj-driver').value = sj.driver || '';
  document.getElementById('sj-client-code').value = sj.clientCode || '';
  document.getElementById('sj-client-name').value = sj.clientName;
  document.getElementById('sj-client-addr').value = sj.clientAddr || '';
  document.getElementById('sj-client-cp').value = sj.clientCp || '';
  document.getElementById('sj-client-tel').value = sj.clientTel || '';
  document.getElementById('sj-sign-select').value = sj.signSelect || 'maker';
  document.getElementById('sj-items-body').innerHTML = '';
  sj.items.forEach(item => addSjItemRow(item));
  calcSjTotal();
  showPage('create-sj');
}

function deleteSuratJalan(id) {
  if (!confirm('Yakin ingin menghapus surat jalan ini?')) return;
  suratJalans = suratJalans.filter(s => s.id !== id);
  saveData(); renderDashboard(); showToast('Surat Jalan dihapus.', 'success');
}

function previewSuratJalan() {
  const sj = {
    no: document.getElementById('sj-no').value,
    date: document.getElementById('sj-date').value,
    po: document.getElementById('sj-po').value,
    polisi: document.getElementById('sj-polisi').value,
    driver: document.getElementById('sj-driver').value,
    clientName: document.getElementById('sj-client-name').value,
    clientAddr: document.getElementById('sj-client-addr').value,
    clientCp: document.getElementById('sj-client-cp').value,
    clientTel: document.getElementById('sj-client-tel').value,
    signSelect: document.getElementById('sj-sign-select').value,
    items: getSjItemsData(),
    total: 0
  };
  sj.total = sj.items.reduce((s, it) => s + (it.qty || 0), 0);
  previewSjData = sj;
  document.getElementById('sj-modal-title').textContent = 'Preview Surat Jalan ' + sj.no;
  document.getElementById('sj-render').innerHTML = renderSjHTML(sj);
  document.getElementById('sj-modal').classList.add('open');
}

function viewSuratJalan(id) {
  const sj = suratJalans.find(s => s.id === id);
  if (!sj) return;
  previewSjData = sj;
  document.getElementById('sj-modal-title').textContent = 'Surat Jalan ' + sj.no;
  document.getElementById('sj-render').innerHTML = renderSjHTML(sj);
  document.getElementById('sj-modal').classList.add('open');
}

function renderSjHTML(sj) {
  const s = settings;
  const logoHTML = s.logo
    ? `<img class="sj-company-logo" src="${s.logo}" alt="logo">`
    : `<div class="sj-company-logo-ph">${(s.companyCode||'MBS').slice(0,3)}</div>`;

  // Determine TTD based on selection
  let signName = '', signTtd = '', signRole = '';
  const sel = sj.signSelect || 'maker';
  if (sel === 'maker')    { signName = s.signMaker || ''; signRole = s.signMakerRole || ''; signTtd = s.ttd_maker || ''; }
  else if (sel === 'quo') { signName = s.quoSignName || ''; signRole = s.quoSignRole || ''; signTtd = s.ttd_quo || ''; }
  else if (sel === 'approver') { signName = s.signApprover || ''; signRole = s.signApproverRole || ''; signTtd = s.ttd_approver || ''; }
  // legacy sj key → fallback to maker
  else { signName = s.signMaker || ''; signRole = s.signMakerRole || ''; signTtd = s.ttd_maker || ''; }

  const npwpParts = [];
  if (s.npwp) npwpParts.push(`NPWP. ${s.npwp}`);
  if (s.pkp) npwpParts.push(`PKP. ${s.pkp}`);
  if (s.email) npwpParts.push(s.email);
  if (s.phone) npwpParts.push(`| ${s.phone}`);

  const itemsHTML = sj.items.map((item, i) => `<tr>
    <td>${i+1}</td>
    <td style="text-align:left">${item.name}</td>
    <td>${item.unit}</td>
    <td>${item.size}</td>
    <td>${item.qty || ''}</td>
    <td style="text-align:left">${item.keterangan || ''}</td>
  </tr>`).join('');

  // Empty rows to fill up to 15 total
  const emptyRows = Math.max(0, 15 - sj.items.length);
  const emptyHTML = Array.from({length: emptyRows}, (_, i) => `<tr>
    <td>${sj.items.length + i + 1}</td>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>`).join('');

  const dateStr = formatDateID(sj.date);

  return `
<div class="sj-page">
  <div style="display:flex;align-items:center;gap:12px;border:1px solid #111;border-bottom:none;padding:10px 16px;background:#fff">
    ${logoHTML}
    <div class="sj-company-info">
      <div class="sj-company-name">${s.companyName}</div>
      <div class="sj-company-addr">${(s.address||'').replace(/\n/g,' ')}${npwpParts.length ? '<br>' + npwpParts.join(' | ') : ''}</div>
    </div>
  </div>
  <div class="sj-title-bar"><span>SURAT JALAN</span></div>

  <div class="sj-meta-row">
    <div class="sj-meta-left">
      <div style="font-size:10px;color:#888;margin-bottom:4px">Penerima :</div>
      <div class="sj-meta-client">${sj.clientName}</div>
      <div class="sj-meta-addr">${(sj.clientAddr||'').replace(/\n/g,'<br>')}</div>
      ${sj.clientCp ? `<div class="sj-meta-up">u.p. ${sj.clientCp}</div>` : ''}
      ${sj.clientTel ? `<div class="sj-meta-up">Tel. ${sj.clientTel}</div>` : ''}
    </div>
    <div class="sj-meta-right">
      <table class="sj-info-table">
        <tr><td>No. Surat Jalan</td><td>:</td><td>${sj.no}</td></tr>
        <tr><td>Nomor PO</td><td>:</td><td>${sj.po || '-'}</td></tr>
        <tr><td>Dikirim/Diambil</td><td>:</td><td>${sj.polisi || '-'}</td></tr>
        <tr><td>No.Polisi</td><td>:</td><td>${sj.polisi || '-'}</td></tr>
        <tr><td>Nama Pengemudi</td><td>:</td><td>${sj.driver || '-'}</td></tr>
        <tr><td>Hari/Tanggal</td><td>:</td><td>${dateStr}</td></tr>
      </table>
    </div>
  </div>

  <div class="sj-notice">Harap terima barang dengan keadaan baik barang-barang di bawah ini</div>

  <table class="sj-items-table">
    <thead>
      <tr>
        <th style="width:30px">NO</th>
        <th>NAMA BARANG</th>
        <th style="width:55px">UNIT</th>
        <th style="width:55px">SIZE</th>
        <th style="width:70px">JUMLAH BARANG</th>
        <th>KETERANGAN</th>
      </tr>
    </thead>
    <tbody>
      ${itemsHTML}
      ${emptyHTML}
      <tr class="sj-total-row">
        <td colspan="4" style="text-align:center;font-weight:700">TOTAL BARANG</td>
        <td style="font-weight:700">${sj.total}</td>
        <td></td>
      </tr>
    </tbody>
  </table>

  <div class="sj-sign-area">
    <div class="sj-sign-col">
      <div style="font-size:10px;color:#555;margin-bottom:6px">Tanda Terima,</div>
      <div class="sj-sign-space"></div>
      <div style="border-top:1px solid #aaa;padding-top:3px;min-width:120px;display:inline-block">..................................</div>
    </div>
    <div class="sj-sign-col">
      <div style="font-size:10px;color:#555;margin-bottom:6px">PIC</div>
      <div class="sj-sign-space">
        ${signTtd ? `<img class="sj-sign-img" src="${signTtd}">` : ''}
      </div>
      <div class="sj-sign-name">${signName}</div>
    </div>
  </div>

  <div class="sj-footer-bar">Terima kasih atas kepercayaan dan kerja sama Anda</div>
</div>`;
}
