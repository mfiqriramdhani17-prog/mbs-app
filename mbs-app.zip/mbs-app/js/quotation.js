// ============================================================
// QUOTATION ITEMS
// ============================================================
function addQuoItemRow(data = null) {
  const tbody = document.getElementById('quo-items-body');
  const idx = quoItemIndex++;
  const usePhoto = document.getElementById('quo-use-photo').checked;
  const imgData = data?.image || '';
  if (imgData) quoItemRowImages[idx] = imgData;

  const row = document.createElement('tr');
  row.id = `quo-item-row-${idx}`;
  row.innerHTML = `
    <td style="text-align:center;color:var(--text2);font-size:12px">${tbody.rows.length + 1}</td>
    <td class="quo-col-photo" style="display:${usePhoto ? 'table-cell' : 'none'}">
      <div class="item-img-cell">
        <img id="quo-img-preview-${idx}" class="item-img-thumb" src="${imgData}" style="display:${imgData ? 'block':'none'}">
        <input type="file" id="quo-img-input-${idx}" accept="image/*" style="display:none" onchange="handleQuoItemImage(${idx}, this)">
        <button class="item-img-btn" onclick="document.getElementById('quo-img-input-${idx}').click()">📷 Pilih</button>
        <button class="item-img-btn" onclick="clearQuoItemImage(${idx})" style="${imgData ? '' : 'display:none'}" id="quo-img-clear-${idx}">✕</button>
      </div>
    </td>
    <td><input type="text" placeholder="Nama item" value="${data?.name || ''}" oninput="calcQuoTotals()" style="width:100%"></td>
    <td><input type="text" placeholder="Pcs" value="${data?.unit || ''}" style="width:100%"></td>
    <td><input type="number" placeholder="0" value="${data?.qty || ''}" oninput="calcQuoTotals()" style="width:100%"></td>
    <td><input type="number" placeholder="0" value="${data?.price || ''}" oninput="calcQuoTotals()" style="width:100%"></td>
    <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--gold)" id="quo-item-amount-${idx}">${data?.qty && data?.price ? fmtRp(data.qty * data.price) : 'Rp 0'}</td>
    <td><button class="remove-row" onclick="removeQuoItemRow(this,'${idx}')">×</button></td>
  `;
  tbody.appendChild(row);
  calcQuoTotals();
  renumberRows('quo-items-body');
}

function handleQuoItemImage(idx, input) {
  const file = input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    quoItemRowImages[idx] = e.target.result;
    const img = document.getElementById(`quo-img-preview-${idx}`);
    const clr = document.getElementById(`quo-img-clear-${idx}`);
    if (img) { img.src = e.target.result; img.style.display = 'block'; }
    if (clr) clr.style.display = '';
  };
  reader.readAsDataURL(file);
}
function clearQuoItemImage(idx) {
  delete quoItemRowImages[idx];
  const img = document.getElementById(`quo-img-preview-${idx}`);
  const clr = document.getElementById(`quo-img-clear-${idx}`);
  if (img) { img.src = ''; img.style.display = 'none'; }
  if (clr) clr.style.display = 'none';
}
function removeQuoItemRow(btn, idx) { btn.closest('tr').remove(); delete quoItemRowImages[idx]; renumberRows('quo-items-body'); calcQuoTotals(); }
function toggleQuoPhotoCol() { const show = document.getElementById('quo-use-photo').checked; document.querySelectorAll('.quo-col-photo').forEach(el => { el.style.display = show ? 'table-cell' : 'none'; }); }
function getQuoItemsData() {
  const rows = document.querySelectorAll('#quo-items-body tr');
  return Array.from(rows).map(r => {
    const inputs = r.querySelectorAll('input[type=text], input[type=number]');
    const idx = r.id.replace('quo-item-row-', '');
    return { name: inputs[0].value, unit: inputs[1].value, qty: parseFloat(inputs[2].value) || 0, price: parseFloat(inputs[3].value) || 0, image: quoItemRowImages[idx] || '' };
  });
}

function calcQuoTotals() {
  const rows = document.querySelectorAll('#quo-items-body tr');
  let sub = 0;
  rows.forEach(r => {
    const inputs = r.querySelectorAll('input[type=number]');
    const numInputs = Array.from(inputs);
    if (numInputs.length >= 2) {
      const qty = parseFloat(numInputs[numInputs.length - 2].value) || 0;
      const price = parseFloat(numInputs[numInputs.length - 1].value) || 0;
      const amt = qty * price;
      sub += amt;
      const idx = r.id.replace('quo-item-row-', '');
      const amtEl = document.getElementById(`quo-item-amount-${idx}`);
      if (amtEl) amtEl.textContent = fmtRp(amt);
    }
  });

  const usePpn = document.getElementById('quo-use-ppn')?.checked;
  const usePph = document.getElementById('quo-use-pph')?.checked;
  const ppnPct = parseFloat(document.getElementById('quo-ppn-pct').value) || 0;
  const pphPct = parseFloat(document.getElementById('quo-pph-pct').value) || 0;

  document.getElementById('quo-ppn-row').style.display = usePpn ? '' : 'none';
  document.getElementById('quo-pph-row').style.display = usePph ? '' : 'none';
  document.getElementById('quo-ppn-display-row').style.display = usePpn ? '' : 'none';
  document.getElementById('quo-pph-display-row').style.display = usePph ? '' : 'none';
  document.getElementById('quo-tax-display').style.display = (usePpn || usePph) ? '' : 'none';

  let ppn = 0, pph = 0, grand = sub;
  if (usePpn) ppn = sub * ppnPct / 100;
  if (usePph) pph = sub * pphPct / 100;
  grand = sub + ppn - pph;

  document.getElementById('quo-ppn-label').textContent = `PPN (${ppnPct}%)`;
  document.getElementById('quo-pph-label').textContent = `PPH (${pphPct}%)`;
  document.getElementById('quo-calc-subtotal').textContent = fmtRp(sub);
  document.getElementById('quo-calc-ppn').textContent = fmtRp(ppn);
  document.getElementById('quo-calc-pph').textContent = fmtRp(pph);
  document.getElementById('quo-calc-grand').textContent = fmtRp(grand);

  return { sub, ppn, pph, grand, ppnPct, pphPct, usePpn, usePph };
}

// ============================================================
// RESET / SAVE / EDIT
// ============================================================
function resetQuoForm() {
  editingQuoId = null; quoItemIndex = 0; quoItemRowImages = {};
  document.getElementById('quo-items-body').innerHTML = '';
  document.getElementById('quo-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('quo-lampiran').value = '2';
  document.getElementById('quo-perihal').value = 'Penawaran Harga';
  document.getElementById('quo-client-code').value = '';
  document.getElementById('quo-client-name').value = '';
  document.getElementById('quo-client-cp').value = '';
  document.getElementById('quo-notes').value = '';
  document.getElementById('quo-use-ppn').checked = false;
  document.getElementById('quo-use-pph').checked = false;
  document.getElementById('quo-ppn-pct').value = 11;
  document.getElementById('quo-pph-pct').value = 2;
  document.getElementById('quo-ppn-row').style.display = 'none';
  document.getElementById('quo-pph-row').style.display = 'none';
  document.getElementById('quo-use-photo').checked = false;
  const badge = document.getElementById('quo-autofill-badge');
  if (badge) badge.style.display = 'none';
  toggleQuoPhotoCol();
  document.getElementById('quo-form-title').textContent = 'Buat Quotation Baru';
  addQuoItemRow();
  regenerateQuoNo();
}

function saveQuotation() {
  const date = document.getElementById('quo-date').value;
  const clientName = document.getElementById('quo-client-name').value;
  if (!date || !clientName) { showToast('Harap isi tanggal dan nama klien!', 'error'); return; }
  const { sub, ppn, pph, grand, ppnPct, pphPct, usePpn, usePph } = calcQuoTotals();
  const items = getQuoItemsData();
  const quo = {
    id: editingQuoId || Date.now().toString(),
    no: document.getElementById('quo-no').value,
    date, lampiran: document.getElementById('quo-lampiran').value,
    perihal: document.getElementById('quo-perihal').value,
    clientCode: document.getElementById('quo-client-code').value,
    clientName, clientCp: document.getElementById('quo-client-cp').value,
    notes: document.getElementById('quo-notes').value,
    usePhoto: document.getElementById('quo-use-photo').checked,
    usePpn, usePph, ppnPct, pphPct,
    items, sub, ppn, pph, grand,
    itemImages: { ...quoItemRowImages }
  };
  if (editingQuoId) { const idx = quotations.findIndex(q => q.id === editingQuoId); if (idx >= 0) quotations[idx] = quo; }
  else quotations.unshift(quo);
  saveData();
  showToast('Quotation berhasil disimpan!', 'success');
  showPage('dashboard');
}

function editQuotation(id) {
  const quo = quotations.find(q => q.id === id);
  if (!quo) return;
  editingQuoId = id; quoItemIndex = 0; quoItemRowImages = {};
  (quo.items || []).forEach((item, i) => { if (item.image) quoItemRowImages[i] = item.image; });
  document.getElementById('quo-form-title').textContent = 'Edit Quotation';
  document.getElementById('quo-no').value = quo.no;
  document.getElementById('quo-date').value = quo.date;
  document.getElementById('quo-lampiran').value = quo.lampiran || '';
  document.getElementById('quo-perihal').value = quo.perihal || 'Penawaran Harga';
  document.getElementById('quo-client-code').value = quo.clientCode || '';
  document.getElementById('quo-client-name').value = quo.clientName;
  document.getElementById('quo-client-cp').value = quo.clientCp || '';
  document.getElementById('quo-notes').value = quo.notes || '';
  document.getElementById('quo-use-ppn').checked = quo.usePpn || false;
  document.getElementById('quo-use-pph').checked = quo.usePph || false;
  document.getElementById('quo-ppn-pct').value = quo.ppnPct || 11;
  document.getElementById('quo-pph-pct').value = quo.pphPct || 2;
  document.getElementById('quo-ppn-row').style.display = quo.usePpn ? '' : 'none';
  document.getElementById('quo-pph-row').style.display = quo.usePph ? '' : 'none';
  document.getElementById('quo-use-photo').checked = quo.usePhoto || false;
  toggleQuoPhotoCol();
  document.getElementById('quo-items-body').innerHTML = '';
  quo.items.forEach(item => addQuoItemRow(item));
  calcQuoTotals();
  showPage('create-quo');
}

function deleteQuotation(id) {
  if (!confirm('Yakin ingin menghapus quotation ini?')) return;
  quotations = quotations.filter(q => q.id !== id);
  saveData(); renderDashboard(); showToast('Quotation dihapus.', 'success');
}

function previewQuotation() {
  const { sub, ppn, pph, grand, ppnPct, pphPct, usePpn, usePph } = calcQuoTotals();
  const quo = {
    no: document.getElementById('quo-no').value,
    date: document.getElementById('quo-date').value,
    lampiran: document.getElementById('quo-lampiran').value,
    perihal: document.getElementById('quo-perihal').value,
    clientName: document.getElementById('quo-client-name').value,
    clientCp: document.getElementById('quo-client-cp').value,
    notes: document.getElementById('quo-notes').value,
    usePhoto: document.getElementById('quo-use-photo').checked,
    usePpn, usePph, ppnPct, pphPct,
    items: getQuoItemsData(), sub, ppn, pph, grand,
    itemImages: { ...quoItemRowImages }
  };
  previewQuoData = quo;
  document.getElementById('quo-modal-title').textContent = 'Preview Quotation ' + quo.no;
  document.getElementById('quo-render').innerHTML = renderQuotationHTML(quo);
  document.getElementById('quo-modal').classList.add('open');
}

function viewQuotation(id) {
  const quo = quotations.find(q => q.id === id);
  if (!quo) return;
  previewQuoData = quo;
  document.getElementById('quo-modal-title').textContent = 'Quotation ' + quo.no;
  document.getElementById('quo-render').innerHTML = renderQuotationHTML(quo);
  document.getElementById('quo-modal').classList.add('open');
}

function renderQuotationHTML(quo) {
  const s = settings;
  const logoHTML = s.logo ? `<img class="quo-logo-img" src="${s.logo}" alt="logo">` : `<div class="quo-logo-placeholder">${(s.companyCode||'MBS').slice(0,3)}</div>`;
  const logoHTML2 = s.logo ? `<img class="quo-logo-ph2" src="${s.logo}" alt="logo">` : `<div class="quo-logo-placeholder quo-logo-ph2" style="width:60px;height:60px;font-size:16px;margin:0 auto 6px;border-radius:8px;background:#FFC000;display:flex;align-items:center;justify-content:center;color:#111;font-weight:800">${(s.companyCode||'MBS').slice(0,3)}</div>`;

  const contactLine = [s.phone, s.email].filter(Boolean).join(' | ');
  const websiteLine = s.website || '';
  const cityDate = 'Bandung, ' + new Date(quo.date + 'T00:00:00').toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

  const page1 = `<div class="quo-page quo-letter">
  <div class="quo-header">
    ${logoHTML}
    <div class="quo-company-block">
      <div class="quo-company-name">${s.companyName}</div>
      <div class="quo-company-addr">${(s.address||'').replace(/\n/g,'<br>')}${contactLine ? '<br>' + contactLine : ''}${websiteLine ? '<br>' + websiteLine : ''}</div>
    </div>
  </div>
  <div class="quo-divider"></div>
  <div class="quo-date-right">${cityDate}</div>
  <table class="quo-meta-table">
    <tr><td>Nomor</td><td>:</td><td><strong>${quo.no}</strong></td></tr>
    <tr><td>Lampiran</td><td>:</td><td>${quo.lampiran || '-'}</td></tr>
    <tr><td>Perihal</td><td>:</td><td>${quo.perihal || 'Penawaran Harga'}</td></tr>
  </table>
  <div class="quo-letter-body">
    <p>Kepada Yth,</p>
    <p><strong>${quo.clientCp ? quo.clientCp : 'Bapak/Ibu'}</strong></p>
    <p><strong>${quo.clientName}</strong></p>
    <p>Di Tempat,</p>
    <br>
    <p>Dengan Hormat,</p>
    <br>
    <p>Bersama surat ini, kami atas nama <strong>${s.companyName}</strong> bermaksud memberikan penawaran item terlampir. Adapun penawaran ini berlaku selama 7 hari.</p>
    <br>
    <p>Demikian surat penawaran harga ini kami sampaikan. Atas kerja sama dan kepercayaannya kami ucapkan terima kasih.</p>
  </div>
  <div class="quo-sign-area">
    <p>Hormat Kami,</p>
    <p>${s.companyName},</p>
    ${s.ttd_quo ? `<img src="${s.ttd_quo}" style="height:80px;max-width:160px;object-fit:contain;display:block;margin:4px 0">` : '<div style="height:80px"></div>'}
    <p><strong><u>${s.quoSignName || ''}</u></strong></p>
    <p style="font-size:10.5px;color:#555">${s.quoSignRole || ''}</p>
  </div>
</div>`;

  const usePhoto = quo.usePhoto;
  const imgCol2 = usePhoto ? `<th style="width:90px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-transform:uppercase">Foto</th>` : '';
  const itemsHTML2 = quo.items.map((item, i) => {
    const imgSrc = item.image || (quo.itemImages && quo.itemImages[i]) || '';
    const imgTd = usePhoto ? `<td style="border:1px solid #ddd">${imgSrc ? `<img class="quo-item-img" src="${imgSrc}">` : ''}</td>` : '';
    return `<tr>
      <td style="border:1px solid #ddd;text-align:center">${i+1}</td>
      <td style="border:1px solid #ddd">${item.name}</td>
      <td style="border:1px solid #ddd;text-align:center">-</td>
      ${imgTd}
      <td style="border:1px solid #ddd;text-align:center">${item.unit}</td>
      <td style="border:1px solid #ddd;text-align:right">${item.qty}</td>
      <td style="border:1px solid #ddd;text-align:right">${fmtRpInv(item.price)}</td>
      <td style="border:1px solid #ddd;text-align:right;font-weight:600">${fmtRpInv(item.qty * item.price)}</td>
    </tr>`;
  }).join('');

  const page2 = `<div class="quo-table-page quo-page-break">
  <div class="quo-table-header">
    ${logoHTML2}
    <div class="quo-company-h2">${s.companyName}</div>
    <div class="quo-divider-h2"></div>
  </div>
  <div class="quo-price-title">Daftar Penawaran Harga :</div>
  <table class="quo-items-table" style="width:100%;border-collapse:collapse">
    <thead><tr style="background-color:#FFC000">
      <th style="width:32px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:left;text-transform:uppercase">NO</th>
      <th style="border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:left;text-transform:uppercase">ITEM</th>
      <th style="width:40px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:left;text-transform:uppercase">DESC</th>
      ${imgCol2}
      <th style="width:55px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:center;text-transform:uppercase">UNIT</th>
      <th style="width:50px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:right;text-transform:uppercase">QTY</th>
      <th style="width:110px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:right;text-transform:uppercase">ITEM PRICE</th>
      <th style="width:120px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px;font-size:10.5px;font-weight:700;text-align:right;text-transform:uppercase">AMOUNT</th>
    </tr></thead>
    <tbody>
      ${itemsHTML2}
      <tr style="background-color:#FFC000;color:#fff">
        <td colspan="${usePhoto?7:6}" style="text-align:center;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px">TOTAL</td>
        <td style="text-align:right;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px">${fmtRpInv(quo.sub)}</td>
      </tr>
      ${quo.usePpn ? `<tr style="background-color:#FFC000;color:#fff"><td colspan="${usePhoto?7:6}" style="text-align:center;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px">PPN (${quo.ppnPct}%)</td><td style="text-align:right;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#fff;padding:8px 10px">${fmtRpInv(quo.ppn)}</td></tr>` : ''}
      ${quo.usePph ? `<tr style="background-color:#FFC000;color:#fff"><td colspan="${usePhoto?7:6}" style="text-align:center;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:8px 10px">PPH (${quo.pphPct}%)</td><td style="text-align:right;font-weight:700;border:1px solid #e6a800;background-color:#FFC000;color:#fff;padding:8px 10px">${fmtRpInv(quo.pph)}</td></tr>` : ''}
      <tr style="background-color:#FFC000;color:#fff">
        <td colspan="${usePhoto?7:6}" style="text-align:center;font-weight:800;font-size:13px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:9px 10px">GRAND TOTAL</td>
        <td style="text-align:right;font-weight:800;font-size:13px;border:1px solid #e6a800;background-color:#FFC000;color:#111;padding:9px 10px">${fmtRpInv(quo.grand)}</td>
      </tr>
    </tbody>
  </table>
  <div class="quo-catatan-box">
    <div class="quo-catatan-title">Catatan :</div>
    <div class="quo-catatan-text">${quo.notes ? quo.notes.replace(/\n/g,'<br>') : ''}</div>
  </div>
  <div class="quo-sign-area2">
    <div class="quo-sign-col2">
      <p style="margin-bottom:4px">Hormat Kami,</p>
      <p style="margin-bottom:4px">${s.companyName},</p>
      ${s.ttd_quo ? `<img src="${s.ttd_quo}" style="height:80px;max-width:160px;object-fit:contain;display:block;margin:4px auto">` : '<div style="height:80px"></div>'}
      <p><strong><u>${s.quoSignName || ''}</u></strong></p>
      <p style="font-size:10px;color:#555">${s.quoSignRole || ''}</p>
    </div>
  </div>
</div>`;

  return page1 + page2;
}
