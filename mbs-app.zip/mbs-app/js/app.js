// ============================================================
// MASTER CLIENT
// ============================================================

// ============================================================
// CLIENT DATALIST
// ============================================================
function refreshClientDatalist() {
  const dl = document.getElementById('client-datalist');
  if (!dl) return;
  dl.innerHTML = clients.map(c => `<option value="${c.code}">${c.name}</option>`).join('');
}

function autofillClientByCode(prefix) {
  const codeEl = document.getElementById(prefix + '-client-code');
  if (!codeEl) return;
  const code = codeEl.value.trim();
  const cl = clients.find(c => c.code && c.code.toUpperCase() === code.toUpperCase());
  if (!cl) return;
  const nameEl = document.getElementById(prefix + '-client-name');
  const addrEl = document.getElementById(prefix + '-client-addr');
  const cpEl   = document.getElementById(prefix + '-client-cp');
  const telEl  = document.getElementById(prefix + '-client-tel');
  if (nameEl) nameEl.value = cl.name    || '';
  if (addrEl) addrEl.value = cl.address || '';
  if (cpEl)   cpEl.value   = cl.contact || '';
  if (telEl)  telEl.value  = cl.phone   || '';
  // Badge
  const badge = document.getElementById(prefix + '-autofill-badge');
  if (badge) { badge.style.display = 'inline-flex'; badge.querySelector('span').textContent = cl.name; }
  showToast('Data klien berhasil diisi otomatis!', 'success');
}

function renderClientsPage() {
  const tbody = document.getElementById('clients-list-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  const empty = document.getElementById('clients-empty');
  const tbl = document.getElementById('clients-table');

  if (clients.length === 0) {
    if (empty) empty.style.display = 'block';
    if (tbl) tbl.style.display = 'none';
  } else {
    if (empty) empty.style.display = 'none';
    if (tbl) tbl.style.display = 'table';
    clients.forEach(cl => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-family:'DM Mono',monospace;font-weight:700;color:var(--gold)">${cl.code}</td>
        <td style="font-weight:600">${cl.name}</td>
        <td style="color:var(--text2);font-size:12px">${(cl.address||'').replace(/\n/g,', ').slice(0,60)}${cl.address && cl.address.length>60?'...':''}</td>
        <td>${cl.contact || '-'}</td>
        <td>${cl.phone || '-'}</td>
        <td>
          <button class="action-btn" onclick="openEditClient('${cl.id}')">
            <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit
          </button>
          <button class="action-btn danger" onclick="deleteClient('${cl.id}')">
            <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus
          </button>
        </td>`;
      tbody.appendChild(tr);
    });
  }
}

function openAddClient() {
  document.getElementById('client-modal-title').textContent = 'Tambah Klien Baru';
  document.getElementById('cl-id').value = '';
  document.getElementById('cl-code').value = '';
  document.getElementById('cl-name').value = '';
  document.getElementById('cl-address').value = '';
  document.getElementById('cl-contact').value = '';
  document.getElementById('cl-phone').value = '';
  document.getElementById('client-modal').classList.add('open');
}

function openEditClient(id) {
  const cl = clients.find(c => c.id === id);
  if (!cl) return;
  document.getElementById('client-modal-title').textContent = 'Edit Klien';
  document.getElementById('cl-id').value = cl.id;
  document.getElementById('cl-code').value = cl.code || '';
  document.getElementById('cl-name').value = cl.name || '';
  document.getElementById('cl-address').value = cl.address || '';
  document.getElementById('cl-contact').value = cl.contact || '';
  document.getElementById('cl-phone').value = cl.phone || '';
  document.getElementById('client-modal').classList.add('open');
}

function saveClient() {
  const code = document.getElementById('cl-code').value.trim().toUpperCase();
  const name = document.getElementById('cl-name').value.trim();
  if (!code || !name) { showToast('Kode dan Nama wajib diisi!', 'error'); return; }

  const existingId = document.getElementById('cl-id').value;
  // Check code uniqueness
  const dup = clients.find(c => c.code === code && c.id !== existingId);
  if (dup) { showToast('Kode klien sudah digunakan!', 'error'); return; }

  const cl = {
    id: existingId || Date.now().toString(),
    code,
    name,
    address: document.getElementById('cl-address').value,
    contact: document.getElementById('cl-contact').value,
    phone: document.getElementById('cl-phone').value
  };

  if (existingId) {
    const idx = clients.findIndex(c => c.id === existingId);
    if (idx >= 0) clients[idx] = cl;
  } else {
    clients.unshift(cl);
  }

  saveData();
  document.getElementById('client-modal').classList.remove('open');
  renderClientsPage();
  showToast('Data klien disimpan!', 'success');
}

function deleteClient(id) {
  if (!confirm('Yakin ingin menghapus klien ini?')) return;
  clients = clients.filter(c => c.id !== id);
  saveData();
  renderClientsPage();
  showToast('Klien dihapus.', 'success');
}

function closeClientModal() {
  document.getElementById('client-modal').classList.remove('open');
}

// ============================================================
// DASHBOARD
// ============================================================
function renderDashboard() {
  const now = new Date();
  const thisMonthInv = invoices.filter(i => { const d = new Date(i.date); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); });
  const thisMonthQuo = quotations.filter(q => { const d = new Date(q.date); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); });
  const thisMonthSj  = suratJalans.filter(s => { const d = new Date(s.date); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); });
  const thisMonthPo  = purchaseOrders.filter(p => { const d = new Date(p.date); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); });

  document.getElementById('stat-total-inv').textContent = invoices.length;
  document.getElementById('stat-total-quo').textContent = quotations.length;
  document.getElementById('stat-total-po').textContent  = purchaseOrders.length;
  document.getElementById('stat-total-sj').textContent  = suratJalans.length;
  document.getElementById('stat-month').textContent = thisMonthInv.length + thisMonthQuo.length + thisMonthSj.length + thisMonthPo.length;
  const totalVal = invoices.reduce((s, i) => s + (i.grand || 0), 0);
  document.getElementById('stat-value').textContent = 'Rp ' + Math.round(totalVal).toLocaleString('id-ID');

  renderInvoiceList();
  renderQuoList();
  renderSjList();
  renderPoList();
}

function renderInvoiceList() {
  const tbody = document.getElementById('invoice-list-body');
  tbody.innerHTML = '';
  const empty = document.getElementById('dashboard-empty');
  const tbl = document.getElementById('dashboard-table');
  if (invoices.length === 0) { empty.style.display = 'block'; tbl.style.display = 'none'; }
  else {
    empty.style.display = 'none'; tbl.style.display = 'table';
    invoices.forEach(inv => {
      const tr = document.createElement('tr');
      const terminBadge = inv.termin === 'PELUNASAN' ? '<span class="badge badge-green">Pelunasan</span>' : `<span class="badge badge-gold">${inv.termin || 'DP'}</span>`;
      tr.innerHTML = `
        <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--gold)">${inv.no}</td>
        <td>${formatDate(inv.date)}</td>
        <td style="font-weight:600">${inv.clientName}</td>
        <td style="color:var(--text2)">${inv.po || '-'}</td>
        <td style="font-family:'DM Mono',monospace;font-size:12.5px">Rp ${Math.round(inv.grand).toLocaleString('id-ID')}</td>
        <td>${terminBadge}</td>
        <td>
          <button class="action-btn primary" onclick="viewInvoice('${inv.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>Lihat</button>
          <button class="action-btn" onclick="editInvoice('${inv.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit</button>
          <button class="action-btn danger" onclick="deleteInvoice('${inv.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus</button>
        </td>`;
      tbody.appendChild(tr);
    });
  }
}

function renderQuoList() {
  const tbody = document.getElementById('quo-list-body');
  tbody.innerHTML = '';
  const empty = document.getElementById('quo-dashboard-empty');
  const tbl = document.getElementById('quo-dashboard-table');
  if (quotations.length === 0) { empty.style.display = 'block'; tbl.style.display = 'none'; }
  else {
    empty.style.display = 'none'; tbl.style.display = 'table';
    quotations.forEach(quo => {
      const tr = document.createElement('tr');
      const taxBadge = (quo.usePpn || quo.usePph)
        ? `<span class="badge badge-blue">${[quo.usePpn ? `PPN ${quo.ppnPct}%` : '', quo.usePph ? `PPH ${quo.pphPct}%` : ''].filter(Boolean).join(' + ')}</span>`
        : '<span class="badge badge-gold">Tanpa Pajak</span>';
      tr.innerHTML = `
        <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--purple)">${quo.no}</td>
        <td>${formatDate(quo.date)}</td>
        <td style="font-weight:600">${quo.clientName}</td>
        <td style="color:var(--text2)">${quo.clientCp || '-'}</td>
        <td style="font-family:'DM Mono',monospace;font-size:12.5px">Rp ${Math.round(quo.grand).toLocaleString('id-ID')}</td>
        <td>${taxBadge}</td>
        <td>
          <button class="action-btn primary" onclick="viewQuotation('${quo.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>Lihat</button>
          <button class="action-btn" onclick="editQuotation('${quo.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit</button>
          <button class="action-btn danger" onclick="deleteQuotation('${quo.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus</button>
        </td>`;
      tbody.appendChild(tr);
    });
  }
}

function renderSjList() {
  const tbody = document.getElementById('sj-list-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  const empty = document.getElementById('sj-dashboard-empty');
  const tbl = document.getElementById('sj-dashboard-table');
  if (suratJalans.length === 0) { if(empty) empty.style.display = 'block'; if(tbl) tbl.style.display = 'none'; }
  else {
    if(empty) empty.style.display = 'none'; if(tbl) tbl.style.display = 'table';
    suratJalans.forEach(sj => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--teal,#14b8a6)">${sj.no}</td>
        <td>${formatDate(sj.date)}</td>
        <td style="font-weight:600">${sj.clientName}</td>
        <td style="color:var(--text2)">${sj.po || '-'}</td>
        <td style="font-family:'DM Mono',monospace">${sj.total || 0}</td>
        <td>
          <button class="action-btn primary" onclick="viewSuratJalan('${sj.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>Lihat</button>
          <button class="action-btn" onclick="editSuratJalan('${sj.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit</button>
          <button class="action-btn danger" onclick="deleteSuratJalan('${sj.id}')"><svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus</button>
        </td>`;
      tbody.appendChild(tr);
    });
  }
}

// ============================================================
// SETTINGS
// ============================================================
function loadSettingsForm() {
  document.getElementById('set-company-name').value = settings.companyName || '';
  document.getElementById('set-company-code').value = settings.companyCode || '';
  document.getElementById('set-address').value = settings.address || '';
  document.getElementById('set-phone').value = settings.phone || '';
  document.getElementById('set-email').value = settings.email || '';
  document.getElementById('set-website').value = settings.website || '';
  document.getElementById('set-npwp').value = settings.npwp || '';
  document.getElementById('set-pkp').value = settings.pkp || '';
  document.getElementById('set-sign-maker').value = settings.signMaker || '';
  document.getElementById('set-sign-maker-role').value = settings.signMakerRole || '';
  document.getElementById('set-sign-approver').value = settings.signApprover || '';
  document.getElementById('set-sign-approver-role').value = settings.signApproverRole || '';
  document.getElementById('set-quo-sign-name').value = settings.quoSignName || '';
  document.getElementById('set-quo-sign-role').value = settings.quoSignRole || '';
  const sjEl = document.getElementById('set-sj-sign-name');
  if (sjEl) sjEl.value = settings.sjSignName || '';

  if (settings.logo) { document.getElementById('logo-preview-img').src = settings.logo; document.getElementById('logo-preview-img').style.display = 'block'; document.getElementById('logo-placeholder-icon').style.display = 'none'; }
  else { document.getElementById('logo-preview-img').style.display = 'none'; document.getElementById('logo-placeholder-icon').style.display = ''; }

  ['maker','approver','quo'].forEach(who => {
    const prev = document.getElementById('ttd-' + who + '-preview');
    const ph = document.getElementById('ttd-' + who + '-placeholder');
    if (settings['ttd_' + who]) { if(prev){prev.src = settings['ttd_' + who]; prev.style.display = 'block';} if(ph) ph.style.display = 'none'; }
    else { if(prev) prev.style.display = 'none'; if(ph) ph.style.display = ''; }
  });
  renderBankEntries();
}

function saveSettings() {
  settings.companyName = document.getElementById('set-company-name').value;
  settings.companyCode = document.getElementById('set-company-code').value.toUpperCase();
  settings.address = document.getElementById('set-address').value;
  settings.phone = document.getElementById('set-phone').value;
  settings.email = document.getElementById('set-email').value;
  settings.website = document.getElementById('set-website').value;
  settings.npwp = document.getElementById('set-npwp').value;
  settings.pkp = document.getElementById('set-pkp').value;
  settings.signMaker = document.getElementById('set-sign-maker').value;
  settings.signMakerRole = document.getElementById('set-sign-maker-role').value;
  settings.signApprover = document.getElementById('set-sign-approver').value;
  settings.signApproverRole = document.getElementById('set-sign-approver-role').value;
  settings.quoSignName = document.getElementById('set-quo-sign-name').value;
  settings.quoSignRole = document.getElementById('set-quo-sign-role').value;
  const sjNameEl = document.getElementById('set-sj-sign-name'); if (sjNameEl) settings.sjSignName = sjNameEl.value;
  saveBankEntries();
  saveData();
  updateSidebarLogo();
  refreshBankSelect(); // Refresh dropdown rekening di form invoice
  showToast('Pengaturan disimpan!', 'success');
}

function updateSidebarLogo() {
  const el = document.getElementById('sidebar-logo-display');
  if (settings.logo) { el.innerHTML = `<img src="${settings.logo}" style="width:32px;height:32px;object-fit:contain;border-radius:6px">`; el.style.background = 'transparent'; }
  else { el.innerHTML = (settings.companyCode || 'MBS').slice(0,3); el.style.background = ''; }
}

function handleLogoUpload(e) {
  const file = e.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    settings.logo = ev.target.result;
    document.getElementById('logo-preview-img').src = ev.target.result;
    document.getElementById('logo-preview-img').style.display = 'block';
    document.getElementById('logo-placeholder-icon').style.display = 'none';
  };
  reader.readAsDataURL(file);
}
function removeLogo() { settings.logo = ''; document.getElementById('logo-preview-img').style.display = 'none'; document.getElementById('logo-placeholder-icon').style.display = ''; }

function handleTtdUpload(who, e) {
  const file = e.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    settings['ttd_' + who] = ev.target.result;
    const prev = document.getElementById('ttd-' + who + '-preview');
    const ph = document.getElementById('ttd-' + who + '-placeholder');
    if (prev) { prev.src = ev.target.result; prev.style.display = 'block'; }
    if (ph) ph.style.display = 'none';
  };
  reader.readAsDataURL(file);
}
function removeTtd(who) {
  settings['ttd_' + who] = '';
  const prev = document.getElementById('ttd-' + who + '-preview');
  const ph = document.getElementById('ttd-' + who + '-placeholder');
  if (prev) { prev.src = ''; prev.style.display = 'none'; }
  if (ph) ph.style.display = '';
  const inp = document.getElementById('ttd-' + who + '-input');
  if (inp) inp.value = '';
}

// BANK ENTRIES
function renderBankEntries() {
  const c = document.getElementById('bank-entries-list');
  c.innerHTML = '';
  (settings.banks || []).forEach((b, i) => {
    const row = document.createElement('div');
    row.className = 'bank-entry-row';
    row.innerHTML = `
      <div class="form-group">${i===0?'<label>Nama Bank</label>':''}<input type="text" placeholder="BCA" value="${b.name}" data-field="name" data-idx="${i}"></div>
      <div class="form-group">${i===0?'<label>No. Rekening</label>':''}<input type="text" placeholder="0123456789" value="${b.account}" data-field="account" data-idx="${i}"></div>
      <div class="form-group">${i===0?'<label>Atas Nama</label>':''}<input type="text" placeholder="CV ..." value="${b.holder}" data-field="holder" data-idx="${i}"></div>
      <button class="remove-bank" onclick="removeBankEntry(${i})" title="Hapus">×</button>`;
    c.appendChild(row);
  });
}
function addBankEntry() { settings.banks = settings.banks || []; settings.banks.push({ name:'', account:'', holder:'' }); renderBankEntries(); }
function removeBankEntry(i) { settings.banks.splice(i,1); renderBankEntries(); }
function saveBankEntries() {
  const inputs = document.querySelectorAll('#bank-entries-list input');
  const banksMap = {};
  inputs.forEach(inp => {
    const idx = parseInt(inp.dataset.idx); const field = inp.dataset.field;
    if (!banksMap[idx]) banksMap[idx] = {};
    banksMap[idx][field] = inp.value;
  });
  settings.banks = Object.values(banksMap);
}

// ============================================================
// PRINT — single unified function, uses global previewXxxData
// ============================================================
function printDoc(type) {
  let html, title, css;
  if (type === 'invoice') {
    if (!previewInvData) { showToast('Tidak ada data invoice untuk dicetak.', 'error'); return; }
    html  = renderInvoiceHTML(previewInvData);
    title = 'Invoice ' + previewInvData.no;
    css   = getInvoicePrintCSS();
  } else if (type === 'sj') {
    if (!previewSjData) { showToast('Tidak ada data surat jalan untuk dicetak.', 'error'); return; }
    html  = renderSjHTML(previewSjData);
    title = 'Surat Jalan ' + previewSjData.no;
    css   = getSjPrintCSS();
  } else if (type === 'po') {
    if (!previewPoData) { showToast('Tidak ada data PO untuk dicetak.', 'error'); return; }
    html  = renderPoHTML(previewPoData);
    title = 'Purchase Order ' + previewPoData.no;
    css   = getPoPrintCSS();
  } else {
    if (!previewQuoData) { showToast('Tidak ada data quotation untuk dicetak.', 'error'); return; }
    html  = renderQuotationHTML(previewQuoData);
    title = 'Quotation ' + previewQuoData.no;
    css   = getQuoPrintCSS();
  }

  const win = window.open('', '_blank');
  if (!win) { showToast('Pop-up diblokir browser. Izinkan pop-up untuk halaman ini.', 'error'); return; }
  win.document.write(`<!DOCTYPE html>
<html><head>
<meta charset="UTF-8">
<title>${title}</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
* { box-sizing:border-box; margin:0; padding:0; -webkit-print-color-adjust:exact !important; print-color-adjust:exact !important; }
body { font-family:'Plus Jakarta Sans',sans-serif; background:#fff; }
@media print { @page { margin:10mm; size:A4; } }
${css}
</style>
</head>
<body onload="setTimeout(()=>{window.focus();window.print();},500)">
<div id="doc-render">${html}</div>
</body></html>`);
  win.document.close();
}

function getInvoicePrintCSS() {
  return `
  #doc-render{background:#fff;color:#111;padding:28px 32px;font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;line-height:1.5}
  .inv-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px}
  .inv-logo-area{display:flex;align-items:center;gap:12px}
  .inv-logo-img{width:48px;height:48px;object-fit:contain}
  .inv-logo-placeholder{width:48px;height:48px;background:#FFC000;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:13px}
  .inv-company-name{font-size:16px;font-weight:800;color:#111}
  .inv-company-addr{font-size:9.5px;color:#555;margin-top:2px;line-height:1.6}
  .inv-npwp-bar{background:#f3f4f6;padding:4px 8px;font-size:9px;color:#555;margin-top:5px;border-radius:3px}
  .inv-badge-area{text-align:right}
  .inv-badge{background:#FFC000 !important;color:#fff !important;font-size:20px;font-weight:800;padding:5px 16px;border-radius:7px;letter-spacing:.04em;display:inline-block;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .inv-meta{text-align:right;margin-top:8px;font-size:10px}
  .inv-meta table{margin-left:auto;border-collapse:collapse}
  .inv-meta td{padding:2px 5px}
  .inv-meta td:first-child{color:#777}
  .inv-meta td:last-child{font-weight:600;color:#111}
  .inv-divider{border:none;border-top:2px solid #FFC000;margin:14px 0 12px}
  .inv-recipient-box{background:#f9fafb;border:1px solid #e5e7eb;border-radius:7px;padding:12px 14px;margin-bottom:14px;font-size:10.5px}
  .inv-recipient-box .label{font-size:9.5px;color:#888;margin-bottom:3px}
  .inv-recipient-box .company{font-size:12px;font-weight:700;color:#111}
  .inv-items-table{width:100%;border-collapse:collapse;margin-bottom:0}
  .inv-items-table thead tr{background:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .inv-items-table th{padding:7px 9px;font-size:9.5px;font-weight:700;text-align:left;text-transform:uppercase;letter-spacing:.04em;background:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .inv-items-table td{padding:8px 9px;border-bottom:1px solid #f0f0f0;font-size:10.5px;vertical-align:top}
  .inv-items-table tbody tr:nth-child(even) td{background:#fafafa}
  .inv-item-img{width:85px;height:75px;object-fit:contain;border-radius:4px;background:#f5f5f5}
  .inv-totals{display:flex;justify-content:flex-end}
  .inv-totals-inner{width:260px}
  .inv-total-row{display:flex;justify-content:space-between;padding:4px 9px;font-size:10.5px;background:#f9fafb}
  .inv-total-row:nth-child(even){background:#f3f4f6}
  .inv-total-grand{display:flex;justify-content:space-between;padding:7px 9px;font-size:12px;font-weight:800;background:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .inv-terbilang{margin-top:8px;background:#fffbf0;border:1px solid #f0e0b0;border-radius:5px;padding:7px 10px;font-size:10px;color:#7a5a00}
  .inv-terbilang span{font-style:italic;font-weight:600}
  .inv-bank-notes{display:flex;gap:14px;margin-top:12px}
  .inv-bank-box{background:#f0f4f8;border:1px solid #dce3ec;border-radius:7px;padding:9px 12px;font-size:10px;flex:1}
  .inv-bank-box .bank-title{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#FFC000;margin-bottom:5px}
  .inv-bank-entry{margin-bottom:3px;color:#444}
  .inv-notes-box{background:#fffbf0;border:1px solid #f0e0b0;border-left:3px solid #FFC000;border-radius:5px;padding:7px 10px;font-size:10px;color:#7a5a00;flex:2}
  .inv-notes-box strong{display:block;margin-bottom:2px;font-size:9px;text-transform:uppercase;letter-spacing:.05em}
  .inv-sign-area{display:flex;justify-content:space-between;align-items:flex-end;margin-top:20px}
  .inv-sign-col{text-align:center;font-size:10px}
  .inv-sign-space{height:75px}
  .inv-sign-name{font-weight:700;font-size:11px;border-top:1px solid #aaa;padding-top:4px;display:inline-block;min-width:110px}
  .inv-sign-role{color:#777;font-size:9.5px}
  .inv-footer-bar{text-align:center;margin-top:16px;padding-top:10px;border-top:2px solid #FFC000;font-style:italic;font-size:10px;color:#888}`;
}

function getSjPrintCSS() {
  return `
  #doc-render{background:#fff;color:#111;padding:24px 28px;font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;line-height:1.5}
  .sj-page{background:#fff}
  .sj-company-logo{width:40px;height:40px;object-fit:contain;flex-shrink:0}
  .sj-company-logo-ph{width:40px;height:40px;background:#FFC000 !important;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:11px;flex-shrink:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .sj-company-name{font-size:13px;font-weight:800;color:#111}
  .sj-company-addr{font-size:9px;color:#555;line-height:1.5}
  .sj-title-bar{background:#FFC000 !important;text-align:center;padding:5px 0;margin:8px 0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .sj-title-bar span{font-weight:800;font-size:12px;color:#fff !important;letter-spacing:.1em}
  .sj-meta-row{display:grid;grid-template-columns:1fr 1fr;border:1px solid #e5e7eb;margin-bottom:8px}
  .sj-meta-left{padding:8px 12px;border-right:1px solid #e5e7eb}
  .sj-meta-right{padding:8px 12px}
  .sj-meta-client{font-size:11px;font-weight:700;color:#111;margin-bottom:2px}
  .sj-meta-addr{font-size:9.5px;color:#444;line-height:1.5;margin-bottom:4px}
  .sj-meta-up{font-size:9.5px;color:#555}
  .sj-info-table{width:100%;font-size:9.5px;border-collapse:collapse}
  .sj-info-table td{padding:2px 5px;vertical-align:top}
  .sj-info-table td:first-child{color:#555;white-space:nowrap}
  .sj-info-table td:nth-child(2){color:#555;padding:2px 3px}
  .sj-info-table td:last-child{font-weight:600;color:#111}
  .sj-notice{background:#fffbf0;border:1px solid #e5e7eb;padding:5px 10px;font-size:9.5px;color:#7a5a00;text-align:center;margin-bottom:7px;font-style:italic}
  .sj-items-table{width:100%;border-collapse:collapse;margin-bottom:0}
  .sj-items-table thead tr{background:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .sj-items-table th{padding:6px 8px;font-size:9px;font-weight:700;text-align:center;text-transform:uppercase;letter-spacing:.04em;border:1px solid #ddd;background:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .sj-items-table td{padding:6px 8px;border:1px solid #eee;font-size:9.5px;text-align:center}
  .sj-items-table td:nth-child(2){text-align:left}
  .sj-total-row td{font-weight:700;background:#f3f4f6}
  .sj-sign-area{display:flex;justify-content:space-between;align-items:flex-end;margin-top:16px}
  .sj-sign-col{text-align:center;font-size:9.5px}
  .sj-sign-space{height:65px;display:flex;align-items:flex-end;justify-content:center}
  .sj-sign-img{max-height:55px;max-width:110px;object-fit:contain}
  .sj-sign-name{font-weight:700;font-size:10px;border-top:1px solid #aaa;padding-top:3px;display:inline-block;min-width:90px}
  .sj-footer-bar{text-align:center;margin-top:12px;padding:5px 0;background:#FFC000 !important;color:#fff !important;font-size:9.5px;font-style:italic;-webkit-print-color-adjust:exact;print-color-adjust:exact}`;
}

function getQuoPrintCSS() {
  return `
  #doc-render{background:#fff;color:#111;font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;line-height:1.5}
  .quo-letter{padding:28px 36px}
  .quo-header{display:flex;align-items:flex-start;gap:14px;margin-bottom:8px}
  .quo-logo-img{width:54px;height:54px;object-fit:contain;flex-shrink:0}
  .quo-logo-placeholder{width:54px;height:54px;background:#FFC000 !important;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:14px;flex-shrink:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .quo-company-block{flex:1}
  .quo-company-name{font-size:17px;font-weight:800;color:#111}
  .quo-company-addr{font-size:9.5px;color:#555;line-height:1.65;margin-top:3px}
  .quo-divider{border:none;border-top:2px solid #111;margin:8px 0 20px}
  .quo-date-right{text-align:right;font-size:11px;margin-bottom:14px}
  .quo-meta-table{font-size:11px;margin-bottom:18px;border-collapse:collapse}
  .quo-meta-table td{padding:2px 5px 2px 0;vertical-align:top}
  .quo-meta-table td:first-child{color:#555;white-space:nowrap}
  .quo-meta-table td:nth-child(2){color:#555;padding:0 6px}
  .quo-meta-table td:last-child{font-weight:600;color:#111}
  .quo-letter-body{font-size:11px;color:#333;line-height:1.8}
  .quo-sign-area{margin-top:32px;font-size:11px}
  .quo-sign-area p{margin-bottom:3px}
  .quo-page-break{page-break-before:always}
  .quo-table-page{padding:24px 32px}
  .quo-table-header{text-align:center;margin-bottom:14px}
  .quo-company-h2{font-size:14px;font-weight:800;color:#111;text-transform:uppercase}
  .quo-divider-h2{border:none;border-top:2px solid #111;margin:6px 0}
  .quo-price-title{font-size:11px;color:#333;margin-bottom:12px}
  .quo-items-table{width:100%;border-collapse:collapse;margin-bottom:0}
  .quo-items-table thead tr{background-color:#FFC000 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact;color:#fff !important}
  .quo-items-table th{padding:7px 8px;font-size:9.5px;font-weight:700;text-align:left;text-transform:uppercase;background-color:#FFC000 !important;color:#fff !important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
  .quo-items-table td{padding:7px 8px;font-size:10.5px;vertical-align:top;border:1px solid #ddd}
  .quo-item-img{width:85px;height:75px;object-fit:contain;border-radius:4px;background:#f5f5f5}
  .quo-catatan-box{border:1px solid #ddd;border-radius:4px;padding:8px 12px;min-height:60px;margin-top:14px}
  .quo-catatan-title{font-size:10px;color:#555;margin-bottom:4px}
  .quo-catatan-text{font-size:10.5px;color:#333}
  .quo-sign-area2{margin-top:20px;display:flex;justify-content:flex-end;font-size:11px}
  .quo-sign-col2{text-align:center}`;
}


function getPoPrintCSS() {
  return `
  #doc-render{background:#fff;color:#111;font-family:'Plus Jakarta Sans',sans-serif;font-size:11px;line-height:1.5}
  `;
}

// ============================================================
// INIT
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
  updateSidebarLogo();
  // Cek apakah File System Access API tersedia
  if (!window.showDirectoryPicker) {
    updateDbStatus('ls', 'Browser tidak mendukung folder (pakai Chrome/Edge)');
  } else {
    updateDbStatus('ls', 'localStorage (sementara)');
  }
  renderDashboard();
  resetForm();
  resetQuoForm();
  resetSjForm();
  resetPoForm();
  refreshBankSelect(0);
  refreshClientDatalist();
  refreshVendorDatalist();
});

// ============================================================
// PURCHASE ORDER LIST RENDER
// ============================================================
function renderPoList() {
  const tbody = document.getElementById('po-list-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  const empty = document.getElementById('po-dashboard-empty');
  const tbl   = document.getElementById('po-dashboard-table');
  if (purchaseOrders.length === 0) {
    if (empty) empty.style.display = 'block';
    if (tbl)   tbl.style.display   = 'none';
    return;
  }
  if (empty) empty.style.display = 'none';
  if (tbl)   tbl.style.display   = 'table';
  purchaseOrders.forEach(po => {
    const tr = document.createElement('tr');
    const useDP = po.useDP;
    const statusLabel = useDP
      ? `<span style="font-size:11px;background:rgba(200,151,42,.15);color:var(--gold);padding:2px 8px;border-radius:4px;font-weight:600">DP + Pelunasan</span>`
      : `<span style="font-size:11px;background:rgba(76,175,130,.15);color:var(--green);padding:2px 8px;border-radius:4px;font-weight:600">Lunas</span>`;
    tr.innerHTML = `
      <td style="font-family:'DM Mono',monospace;font-weight:700;color:#3b82f6;font-size:12px">${po.no}</td>
      <td style="color:var(--text2);font-size:12px">${formatDateShort(po.date)}</td>
      <td style="font-weight:600">${po.vendorName}</td>
      <td style="font-family:'DM Mono',monospace;font-size:12px;color:var(--gold)">Rp ${Math.round(po.total).toLocaleString('id-ID')}</td>
      <td>${statusLabel}</td>
      <td>
        <button class="action-btn" onclick="viewPurchaseOrder('${po.id}')">
          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>View
        </button>
        <button class="action-btn" onclick="editPurchaseOrder('${po.id}')">
          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit
        </button>
        <button class="action-btn danger" onclick="deletePurchaseOrder('${po.id}')">
          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus
        </button>
      </td>`;
    tbody.appendChild(tr);
  });
}

