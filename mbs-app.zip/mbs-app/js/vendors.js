// ============================================================
// MASTER VENDOR
// ============================================================
let editingVendorId = null;

function renderVendorsPage() {
  const tbody = document.getElementById('vendors-list-body');
  if (!tbody) return;
  tbody.innerHTML = '';
  const empty = document.getElementById('vendors-empty');
  const tbl   = document.getElementById('vendors-table');
  if (vendors.length === 0) {
    if (empty) empty.style.display = 'block';
    if (tbl)   tbl.style.display   = 'none';
    return;
  }
  if (empty) empty.style.display = 'none';
  if (tbl)   tbl.style.display   = 'table';
  vendors.forEach(v => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="font-weight:700;color:var(--gold)">${v.name}</td>
      <td style="color:var(--text2);font-size:12px">${v.cp || '-'}</td>
      <td style="font-size:12px">${v.tel || '-'}</td>
      <td style="font-size:12px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${(v.addr || '-').replace(/\n/g,', ')}</td>
      <td>
        <button class="action-btn" onclick="editVendor('${v.id}')">
          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>Edit
        </button>
        <button class="action-btn danger" onclick="deleteVendor('${v.id}')">
          <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>Hapus
        </button>
      </td>`;
    tbody.appendChild(tr);
  });
  refreshVendorDatalist();
}

function saveVendor() {
  const name = (document.getElementById('vendor-form-name')?.value || '').trim();
  if (!name) { showToast('Nama vendor wajib diisi!', 'error'); return; }
  const v = {
    id:   editingVendorId || Date.now().toString(),
    name,
    cp:   (document.getElementById('vendor-form-cp')?.value   || '').trim(),
    tel:  (document.getElementById('vendor-form-tel')?.value  || '').trim(),
    addr: (document.getElementById('vendor-form-addr')?.value || '').trim()
  };
  if (editingVendorId) {
    const idx = vendors.findIndex(x => x.id === editingVendorId);
    if (idx >= 0) vendors[idx] = v; else vendors.unshift(v);
  } else {
    vendors.unshift(v);
  }
  editingVendorId = null;
  clearVendorForm();
  saveData();
  renderVendorsPage();
  showToast('Vendor berhasil disimpan!', 'success');
}

function editVendor(id) {
  const v = vendors.find(x => x.id === id);
  if (!v) return;
  editingVendorId = id;
  document.getElementById('vendor-form-name').value = v.name;
  document.getElementById('vendor-form-cp').value   = v.cp || '';
  document.getElementById('vendor-form-tel').value  = v.tel || '';
  document.getElementById('vendor-form-addr').value = v.addr || '';
  document.getElementById('vendor-form-title').textContent = 'Edit Vendor';
  document.getElementById('vendor-form-name').focus();
}

function deleteVendor(id) {
  if (!confirm('Yakin hapus vendor ini?')) return;
  vendors = vendors.filter(x => x.id !== id);
  saveData(); renderVendorsPage(); showToast('Vendor dihapus.', 'success');
}

function clearVendorForm() {
  editingVendorId = null;
  ['vendor-form-name','vendor-form-cp','vendor-form-tel','vendor-form-addr'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const t = document.getElementById('vendor-form-title');
  if (t) t.textContent = 'Tambah Vendor Baru';
}

function refreshVendorDatalist() {
  const dl = document.getElementById('vendor-datalist');
  if (!dl) return;
  dl.innerHTML = vendors.map(v => `<option value="${v.name}" data-id="${v.id}">`).join('');
}

function autofillVendorFromInput(inputEl) {
  const name = inputEl.value.trim();
  const v = vendors.find(x => x.name.toLowerCase() === name.toLowerCase());
  if (!v) return;
  // Fill PO vendor fields
  const cpEl   = document.getElementById('po-vendor-cp');
  const telEl  = document.getElementById('po-vendor-tel');
  const addrEl = document.getElementById('po-vendor-addr');
  if (cpEl)   cpEl.value   = v.cp   || '';
  if (telEl)  telEl.value  = v.tel  || '';
  if (addrEl) addrEl.value = v.addr || '';
}
